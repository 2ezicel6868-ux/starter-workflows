#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TaCZ 1.1.8 枪包自检 —— 关键是**对着实例里真实的默认枪包**做交叉校验。

检查：
  1. 枪包元数据 / 语言文件（en/zh 键集合相等）；
  2. 每把枪 index→display / data 引用可解析；
  3. display 里 animation / state_machine / sounds / hud / muzzle_flash 在
     TaCZ 默认包里**真实存在**（跨枪包引用必须能落到文件）；
  4. data 里 ammo 是 TaCZ 真实弹药 id；
  5. JSON 顶层键不超出真实 schema（防拼写错误）；
  6. geo 模型必需组完整；贴图尺寸正确；
  7. 配方在 data/<ns>/recipes/gun/ 且结构与 1.1.8 一致。

用法：
    python tools/validate_tacz_pack.py
    python tools/validate_tacz_pack.py --tacz-pack "E:/...../tacz/tacz_default_gun"
"""

from __future__ import annotations

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK = os.path.join(ROOT, "tacz_pack", "d2arsenal_gun_pack")
NS = "d2arsenal"
DEFAULT_TACZ_PACK = r"E:\mc\libs\.minecraft\versions\逆转未来2.3.3\tacz\tacz_default_gun"

# 真实 schema 的顶层键（从默认包 ak47 的三个文件里抄下来的）
DATA_KEYS = {
    "ammo", "ammo_amount", "extended_mag_ammo_amount", "script", "script_param",
    "can_crawl", "can_slide", "bolt", "rpm", "bullet", "fire_sound", "reload", "heat",
    "charging", "draw_time", "put_away_time", "aim_time", "sprint_time", "bolt_action_time",
    "weight", "movement_speed", "fire_mode", "fire_mode_adjust", "burst_data",
    "crawl_recoil_multiplier", "recoil", "hurt_bob_tweak_multiplier", "inaccuracy", "melee",
    "allow_attachment_types", "builtin_attachments", "exclusive_attachments",
}
DISPLAY_KEYS = {
    "model", "texture", "lod", "hud", "hud_empty", "slot", "ammo_count_style", "damage_style",
    "animation", "state_machine", "use_default_animation", "third_person_animation",
    "player_animator_3rd", "show_crosshair", "transform", "muzzle_flash", "iron_zoom",
    "zoom_model_fov", "shell", "ammo", "sounds", "offhand_show", "hotbar_show", "text_show",
    "controllable",
}
INDEX_KEYS = {"name", "display", "data", "tooltip", "type", "item_type", "sort"}
RECIPE_KEYS = {"materials", "result", "type"}
VALID_TYPES = {"pistol", "sniper", "rifle", "shotgun", "smg", "mg", "rpg"}

errors: list[str] = []
checked = 0


def fail(msg: str) -> None:
    errors.append(msg)


def ok() -> None:
    global checked
    checked += 1


def rel(path: str) -> str:
    return os.path.relpath(path, PACK).replace("\\", "/")


def load(path: str):
    if not os.path.isfile(path):
        fail(f"文件不存在: {rel(path)}")
        return None
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        ok()
        return data
    except Exception as exc:  # noqa: BLE001
        fail(f"JSON 解析失败 {rel(path)}: {exc}")
        return None


def png_size(path: str) -> tuple:
    with open(path, "rb") as handle:
        head = handle.read(24)
    if len(head) < 24 or head[1:4] != b"PNG":
        return (-1, -1)
    return (int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big"))


def rid(value: str) -> tuple[str, str]:
    return value.split(":", 1) if ":" in value else (NS, value)


class TaczDefault:
    """实例里真实的 TaCZ 默认枪包，用于验证跨包引用。"""

    def __init__(self, root: str) -> None:
        self.root = root
        self.available = os.path.isdir(root)

    def ammo_ids(self) -> set[str]:
        index_dir = os.path.join(self.root, "data", "tacz", "index", "ammo")
        if not os.path.isdir(index_dir):
            return set()
        return {name[:-5] for name in os.listdir(index_dir) if name.endswith(".json")}

    def animation(self, stem: str) -> bool:
        return os.path.isfile(os.path.join(self.root, "assets", "tacz", "animations",
                                           f"{stem}.animation.json"))

    def state_machine(self, stem: str) -> bool:
        return os.path.isfile(os.path.join(self.root, "assets", "tacz", "scripts",
                                           f"{stem}_state_machine.lua"))

    def sound(self, path: str) -> bool:
        # "tacz:stem/stem_shoot" -> assets/tacz/tacz_sounds/stem/stem_shoot.ogg
        ns, rest = rid(path)
        if ns != "tacz":
            return False
        return os.path.isfile(os.path.join(self.root, "assets", "tacz", "tacz_sounds",
                                           rest + ".ogg"))

    def texture(self, path: str) -> bool:
        ns, rest = rid(path)
        if ns != "tacz":
            return False
        return os.path.isfile(os.path.join(self.root, "assets", "tacz", "textures", rest + ".png"))


def check_schema(label: str, payload: dict, allowed: set) -> None:
    unknown = set(payload) - allowed
    if unknown:
        fail(f"{label}: 出现未知字段 {sorted(unknown)}（1.1.8 schema 里没有）")
    else:
        ok()


def main() -> int:
    tacz_root = DEFAULT_TACZ_PACK
    if "--tacz-pack" in sys.argv:
        tacz_root = sys.argv[sys.argv.index("--tacz-pack") + 1]
    tacz = TaczDefault(tacz_root)

    print("开始校验 TaCZ 1.1.8 枪包…")
    print(f"  默认枪包: {tacz_root}  ({'可读' if tacz.available else '不可读，跳过跨包校验'})")
    if not tacz.available:
        fail("读不到 TaCZ 默认枪包，无法校验动画/音效/弹药引用；用 --tacz-pack 指定路径")

    meta = load(os.path.join(PACK, "gunpack.meta.json"))
    if meta is not None:
        if meta.get("namespace") != NS:
            fail(f"namespace 应为 {NS}")
        else:
            ok()
        if "tacz" not in (meta.get("dependencies") or {}):
            fail("缺少 tacz 依赖声明")
        else:
            ok()

    langs = {}
    for locale in ("en_us", "zh_cn"):
        langs[locale] = load(os.path.join(PACK, "assets", NS, "lang", f"{locale}.json")) or {}
    if set(langs["en_us"]) != set(langs["zh_cn"]):
        fail("en_us 与 zh_cn 语言键不一致")
    else:
        ok()

    if tacz.available:
        valid_ammo = tacz.ammo_ids()
        if len(valid_ammo) < 20:
            fail(f"默认包弹药数量异常: {len(valid_ammo)}")
        else:
            ok()

    index_dir = os.path.join(PACK, "data", NS, "index", "guns")
    gun_ids = sorted(name[:-5] for name in os.listdir(index_dir) if name.endswith(".json"))
    if len(gun_ids) != 8:
        fail(f"枪械数量应为 8，实际 {len(gun_ids)}")
    else:
        ok()

    for gun_id in gun_ids:
        index = load(os.path.join(index_dir, f"{gun_id}.json"))
        if index is None:
            continue
        check_schema(f"[{gun_id}] index", index, INDEX_KEYS)
        if index.get("type") not in VALID_TYPES:
            fail(f"[{gun_id}] type 非法: {index.get('type')}")
        else:
            ok()
        for key in ("name", "tooltip"):
            if index.get(key) not in langs["en_us"]:
                fail(f"[{gun_id}] 语言键缺失: {index.get(key)}")
            else:
                ok()

        # display
        ns, path = rid(index.get("display", ""))
        display = load(os.path.join(PACK, "assets", ns, "display", "guns", path + ".json"))
        if display is not None:
            check_schema(f"[{gun_id}] display", display, DISPLAY_KEYS)
            model_ns, model_path = rid(display.get("model", ""))
            if not os.path.isfile(os.path.join(PACK, "assets", model_ns, "geo_models",
                                               model_path + ".json")):
                fail(f"[{gun_id}] 模型找不到: {display.get('model')}")
            else:
                ok()
            for field in ("texture", "slot"):
                tex_ns, tex_path = rid(display.get(field, ""))
                if not os.path.isfile(os.path.join(PACK, "assets", tex_ns, "textures",
                                                   tex_path + ".png")):
                    fail(f"[{gun_id}] {field} 找不到: {display.get(field)}")
                else:
                    ok()
            if tacz.available:
                animation = display.get("animation", "")
                stem = rid(animation)[1]
                if not tacz.animation(stem):
                    fail(f"[{gun_id}] 动画在默认包中不存在: {animation}")
                else:
                    ok()
                sm = display.get("state_machine", "")
                if not tacz.state_machine(rid(sm)[1].replace("_state_machine", "")):
                    fail(f"[{gun_id}] 状态机在默认包中不存在: {sm}")
                else:
                    ok()
                for key, sound in (display.get("sounds") or {}).items():
                    if not tacz.sound(sound):
                        fail(f"[{gun_id}] 音效文件不存在: {key} -> {sound}")
                    else:
                        ok()
                if "hud" in display and not tacz.texture(display["hud"]):
                    fail(f"[{gun_id}] HUD 贴图不存在: {display['hud']}")
                elif "hud" in display:
                    ok()
                flash = (display.get("muzzle_flash") or {}).get("texture")
                if flash and not tacz.texture(flash):
                    fail(f"[{gun_id}] 枪口焰贴图不存在: {flash}")
                else:
                    ok()

            # geo
            geo = load(os.path.join(PACK, "assets", model_ns, "geo_models", model_path + ".json"))
            if geo is not None:
                bones = (geo.get("minecraft:geometry") or [{}])[0].get("bones") or []
                names = {bone.get("name") for bone in bones}
                required = ("root", "magazine", "mag_standard", "lefthand_pos", "righthand_pos",
                            "idle_view", "iron_view", "ground", "thirdperson_hand", "fixed")
                missing = [g for g in required if g not in names]
                if missing:
                    fail(f"[{gun_id}] 模型缺少必需组 {missing}")
                else:
                    ok()
                if len(names) != len(bones):
                    fail(f"[{gun_id}] 模型组名重复")
                else:
                    ok()
                for hand in ("lefthand_pos", "righthand_pos"):
                    bone = next((b for b in bones if b.get("name") == hand), None)
                    cubes = (bone or {}).get("cubes") or []
                    if len(cubes) != 1 or cubes[0].get("size") != [4, 12, 4]:
                        fail(f"[{gun_id}] {hand} 手臂预览方块应为 4x12x4")
                    else:
                        ok()

            tex_ns, tex_path = rid(display.get("texture", ""))
            tex_file = os.path.join(PACK, "assets", tex_ns, "textures", tex_path + ".png")
            if os.path.isfile(tex_file):
                if png_size(tex_file) != (64, 64):
                    fail(f"[{gun_id}] 模型贴图应为 64x64")
                else:
                    ok()
            slot_ns, slot_path = rid(display.get("slot", ""))
            slot_file = os.path.join(PACK, "assets", slot_ns, "textures", slot_path + ".png")
            if os.path.isfile(slot_file):
                if png_size(slot_file) != (32, 32):
                    fail(f"[{gun_id}] 背包贴图应为 32x32")
                else:
                    ok()

        # data
        ns, path = rid(index.get("data", ""))
        gun_data = load(os.path.join(PACK, "data", ns, "data", "guns", path + ".json"))
        if gun_data is not None:
            check_schema(f"[{gun_id}] data", gun_data, DATA_KEYS)
            ammo = gun_data.get("ammo", "")
            ammo_ns, ammo_path = rid(ammo)
            if ammo_ns != "tacz":
                fail(f"[{gun_id}] 应复用 TaCZ 弹药，实际 {ammo}")
            elif tacz.available and ammo_path not in tacz.ammo_ids():
                fail(f"[{gun_id}] 弹药 id 不存在于默认包: {ammo}")
            else:
                ok()
            if not (1 <= gun_data.get("rpm", 0) <= 1200):
                fail(f"[{gun_id}] rpm 超出 1..1200: {gun_data.get('rpm')}")
            else:
                ok()
            bullet = gun_data.get("bullet") or {}
            for field in ("life", "damage", "speed", "gravity", "pierce", "extra_damage"):
                if field not in bullet:
                    fail(f"[{gun_id}] bullet 缺少 {field}")
                else:
                    ok()
            reload_block = gun_data.get("reload") or {}
            for section in ("feed", "cooldown"):
                pair = reload_block.get(section) or {}
                if "empty" not in pair or "tactical" not in pair:
                    fail(f"[{gun_id}] reload.{section} 缺少 empty/tactical")
                else:
                    ok()
            for field in ("stand", "move", "sneak", "lie", "aim"):
                if field not in (gun_data.get("inaccuracy") or {}):
                    fail(f"[{gun_id}] inaccuracy 缺少 {field}")
                else:
                    ok()

        # 配方
        recipe = load(os.path.join(PACK, "data", NS, "recipes", "gun", f"{gun_id}.json"))
        if recipe is not None:
            check_schema(f"[{gun_id}] recipe", recipe, RECIPE_KEYS)
            if recipe.get("type") != "tacz:gun_smith_table_crafting":
                fail(f"[{gun_id}] 配方 type 应为 tacz:gun_smith_table_crafting")
            else:
                ok()
            result = recipe.get("result") or {}
            if result.get("type") != "gun" or result.get("id") != f"{NS}:{gun_id}":
                fail(f"[{gun_id}] 配方 result 错误: {result}")
            else:
                ok()
            for material in recipe.get("materials") or []:
                item = material.get("item") or {}
                target = item.get("tag") or item.get("item")
                if not target:
                    fail(f"[{gun_id}] 配方材料缺少 item/tag")
                else:
                    ok()

    print()
    if errors:
        print(f"校验失败：{len(errors)} 个问题")
        for msg in errors:
            print("  -", msg)
        return 1
    print(f"校验通过：{checked} 项检查全部 OK（{len(gun_ids)} 把枪，已对齐 TaCZ 1.1.8 真格式）")
    return 0


if __name__ == "__main__":
    sys.exit(main())
