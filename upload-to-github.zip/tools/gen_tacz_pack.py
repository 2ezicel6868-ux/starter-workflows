#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TaCZ 枪包生成器 —— 面向 **TaCZ 1.1.8 / Minecraft 1.20.1 Forge**。

与 1.21.1 版的差异（全部按实例里 tacz_default_gun 的真实文件核对过）：
  * 配方目录是 data/<ns>/recipes/gun/（复数），配方类型 tacz:gun_smith_table_crafting
  * 枪械 display 需要 animation / state_machine / use_default_animation / sounds
  * 弹药直接复用 TaCZ 默认包的真实弹药（45acp / 762x39 / 338 / 40mm / rpg_rocket），
    不再自带弹药 → 玩家用 TaCZ 的弹药，天然互通
  * 动画与状态机复用默认包已有的组合（见 TACZ_BINDING.stem），音效同理

产出结构：
    d2arsenal_gun_pack/
      gunpack.meta.json
      assets/d2arsenal/{gunpack_info.json, lang/, geo_models/, textures/, display/guns/}
      data/d2arsenal/{index/guns/, data/guns/, recipes/gun/}

用法：python tools/gen_tacz_pack.py
"""

from __future__ import annotations

import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK_NAME = "d2arsenal_gun_pack"
NS = "d2arsenal"
PACK_ROOT = os.path.join(ROOT, "tacz_pack", PACK_NAME)

# ---------------------------------------------------------------- 调色板
# 64x64 图集 = 4x4 个 16x16 纯色块
PALETTE = {
    "dark": (0, 0), "base": (16, 0), "mid": (32, 0), "light": (48, 0),
    "gold": (0, 16), "solar": (16, 16), "arc": (32, 16), "void": (48, 16),
    "kinetic": (0, 32), "black": (16, 32), "steel": (32, 32), "rubber": (48, 32),
}
PALETTE_RGB = {
    "dark": (32, 35, 42), "base": (56, 62, 74), "mid": (104, 113, 128),
    "light": (176, 186, 200), "gold": (208, 170, 74), "solar": (255, 122, 47),
    "arc": (111, 211, 255), "void": (178, 105, 255), "kinetic": (216, 222, 230),
    "black": (18, 20, 24), "steel": (140, 150, 165), "rubber": (44, 46, 52),
}
ELEMENT_SLOT = {"kinetic": "kinetic", "solar": "solar", "arc": "arc", "void": "void"}

# ---------------------------------------------------------------- 武器
# 数值对照 core/WeaponCatalog.java：mag=弹匣, tick=射击间隔(20=1s), reload=换弹 tick
GUNS = [
    {"id": "gjallarhorn", "en": "Gjallarhorn", "zh": "狼嚎", "type": "rpg",
     "archetype": "launcher", "element": "solar", "mag": 1, "tick": 30, "damage": 24.0,
     "speed": 60.0, "life": 10.0, "gravity": 0.02, "pierce": 0, "explosion": 4.0,
     "reload": 70, "auto": False, "sort": 10},
    {"id": "last_word", "en": "The Last Word", "zh": "最后的话语", "type": "pistol",
     "archetype": "handcannon", "element": "kinetic", "mag": 8, "tick": 4, "damage": 7.0,
     "speed": 300.0, "life": 0.8, "gravity": 0.0, "pierce": 1, "explosion": 0.0,
     "reload": 40, "auto": True, "sort": 20},
    {"id": "fatebringer", "en": "Fatebringer", "zh": "命运终结者", "type": "pistol",
     "archetype": "handcannon", "element": "kinetic", "mag": 12, "tick": 8, "damage": 9.0,
     "speed": 320.0, "life": 0.8, "gravity": 0.0, "pierce": 1, "explosion": 0.0,
     "reload": 36, "auto": False, "sort": 30},
    {"id": "thunderlord", "en": "Thunderlord", "zh": "雷神", "type": "mg",
     "archetype": "rifle", "element": "arc", "mag": 60, "tick": 4, "damage": 5.0,
     "speed": 400.0, "life": 1.2, "gravity": 0.0, "pierce": 2, "explosion": 0.0,
     "reload": 60, "auto": True, "sort": 40},
    {"id": "sunshot", "en": "Sunshot", "zh": "旭日", "type": "pistol",
     "archetype": "handcannon", "element": "solar", "mag": 8, "tick": 7, "damage": 8.0,
     "speed": 300.0, "life": 0.8, "gravity": 0.0, "pierce": 1, "explosion": 0.0,
     "reload": 34, "auto": False, "sort": 50},
    {"id": "izanagis_burden", "en": "Izanagi's Burden", "zh": "伊邪那岐的重担", "type": "sniper",
     "archetype": "sniper", "element": "kinetic", "mag": 4, "tick": 20, "damage": 18.0,
     "speed": 900.0, "life": 2.0, "gravity": 0.0, "pierce": 4, "explosion": 0.0,
     "reload": 50, "auto": False, "sort": 60},
    {"id": "mountaintop", "en": "Mountaintop", "zh": "山巅", "type": "rpg",
     "archetype": "launcher", "element": "kinetic", "mag": 1, "tick": 25, "damage": 16.0,
     "speed": 120.0, "life": 10.0, "gravity": 0.03, "pierce": 0, "explosion": 5.0,
     "reload": 45, "auto": False, "sort": 70},
    {"id": "graviton_lance", "en": "Graviton Lance", "zh": "引力子长矛", "type": "rifle",
     "archetype": "rifle", "element": "void", "mag": 30, "tick": 6, "damage": 6.0,
     "speed": 500.0, "life": 1.2, "gravity": 0.0, "pierce": 2, "explosion": 0.0,
     "reload": 44, "auto": True, "sort": 80},
]

# 与 TaCZ 1.1.8 默认包的绑定：弹药 / 借用动画+状态机 / 音效 stem / 配方材料
# stem 必须同时存在 <stem>.animation.json 与 <stem>_state_machine.lua（已核对）
TACZ_BINDING = {
    "gjallarhorn": {"ammo": "tacz:rpg_rocket", "stem": "m870", "hud": True,
                    "default_anim": "rifle", "iron_zoom": 1.0, "zoom_fov": 70,
                    "tracer": "#FF7A2F",
                    "materials": [("forge:ingots/iron", 40), ("forge:gunpowder", 8),
                                  ("forge:rods/blaze", 6)]},
    "last_word": {"ammo": "tacz:45acp", "stem": "timeless50", "hud": False,
                  "default_anim": "pistol", "iron_zoom": 1.15, "zoom_fov": 60,
                  "tracer": "#D8DEE6",
                  "materials": [("forge:ingots/iron", 26), ("forge:gunpowder", 6),
                                ("forge:gems/diamond", 2), ("forge:gems/lapis", 4)]},
    "fatebringer": {"ammo": "tacz:45acp", "stem": "timeless50", "hud": False,
                    "default_anim": "pistol", "iron_zoom": 1.2, "zoom_fov": 55,
                    "tracer": "#D8DEE6",
                    "materials": [("forge:ingots/iron", 28), ("forge:gunpowder", 6),
                                  ("forge:gems/emerald", 2), ("forge:gems/lapis", 4)]},
    "thunderlord": {"ammo": "tacz:762x39", "stem": "m249", "hud": True,
                    "default_anim": "rifle", "iron_zoom": 1.15, "zoom_fov": 60,
                    "tracer": "#6FD3FF",
                    "materials": [("forge:ingots/iron", 44), ("forge:gunpowder", 10),
                                  ("forge:ingots/copper", 12)]},
    "sunshot": {"ammo": "tacz:45acp", "stem": "timeless50", "hud": False,
                "default_anim": "pistol", "iron_zoom": 1.15, "zoom_fov": 60,
                "tracer": "#FF7A2F",
                "materials": [("forge:ingots/iron", 26), ("forge:gunpowder", 8),
                              ("forge:rods/blaze", 4)]},
    "izanagis_burden": {"ammo": "tacz:338", "stem": "m107", "hud": True,
                        "default_anim": "rifle", "iron_zoom": 4.0, "zoom_fov": 30,
                        "tracer": "#D8DEE6",
                        "materials": [("forge:ingots/iron", 32), ("forge:gunpowder", 6),
                                      ("forge:gems/amethyst", 8)]},
    "mountaintop": {"ammo": "tacz:40mm", "stem": "m870", "hud": True,
                    "default_anim": "rifle", "iron_zoom": 1.0, "zoom_fov": 70,
                    "tracer": "#D8DEE6",
                    "materials": [("forge:ingots/iron", 30), ("forge:gunpowder", 16),
                                  ("forge:dusts/redstone", 6)]},
    "graviton_lance": {"ammo": "tacz:762x39", "stem": "ak47", "hud": True,
                       "default_anim": "rifle", "iron_zoom": 1.25, "zoom_fov": 55,
                       "tracer": "#B269FF",
                       "materials": [("forge:ingots/iron", 34), ("forge:gunpowder", 8),
                                     ("forge:ender_pearls", 4)]},
}

ARCH_RANGE = {"handcannon": 26, "rifle": 34, "sniper": 64, "launcher": 44}
ARCH_WEIGHT = {"handcannon": 1.5, "rifle": 3.5, "sniper": 5.0, "launcher": 6.5}
ARCH_SPREAD = {"handcannon": 2.0, "rifle": 1.6, "sniper": 0.35, "launcher": 0.8}
ARCH_RECOIL = {"handcannon": 0.7, "rifle": 0.45, "sniper": 1.0, "launcher": 1.2}

# ---------------------------------------------------------------- 几何
# 枪口朝 -Z，+Y 向上，1 单位 = 1/16 格
ARCHETYPES = {
    "handcannon": [
        ("root", (-2.0, 0.0, -12.0), (4.0, 3.0, 9.0), "base"),
        ("root", (-1.0, 1.5, -18.0), (2.0, 2.0, 6.0), "mid"),
        ("root", (-1.0, 1.5, -19.0), (2.0, 2.0, 1.0), "accent"),
        ("root", (-1.5, -4.0, -3.0), (3.0, 4.0, 3.0), "rubber"),
        ("root", (-0.6, 3.0, -9.0), (1.2, 1.0, 2.0), "light"),
        ("root", (-2.0, 3.0, -14.0), (4.0, 0.8, 6.0), "gold"),
        ("magazine", (-1.2, -6.0, -8.0), (2.4, 6.0, 2.4), "mid"),
    ],
    "rifle": [
        ("root", (-2.0, 0.0, -14.0), (4.0, 3.0, 10.0), "base"),
        ("root", (-1.0, 1.5, -22.0), (2.0, 2.0, 8.0), "mid"),
        ("root", (-1.0, 1.5, -23.5), (2.0, 2.0, 1.5), "accent"),
        ("root", (-1.5, -4.0, -3.0), (3.0, 4.0, 3.0), "rubber"),
        ("root", (-1.5, 0.5, -4.0), (3.0, 2.5, 5.0), "dark"),
        ("root", (-0.6, 3.0, -10.0), (1.2, 1.2, 3.0), "light"),
        ("root", (-2.0, 3.0, -16.0), (4.0, 0.7, 8.0), "gold"),
        ("magazine", (-1.5, -5.0, -9.0), (3.0, 6.0, 2.5), "mid"),
    ],
    "sniper": [
        ("root", (-2.0, 0.0, -14.0), (4.0, 3.0, 10.0), "base"),
        ("root", (-1.0, 1.5, -28.0), (2.0, 2.0, 14.0), "mid"),
        ("root", (-1.0, 1.5, -29.5), (2.0, 2.0, 1.5), "accent"),
        ("root", (-1.5, -4.5, -3.0), (3.0, 4.5, 3.0), "rubber"),
        ("root", (-1.5, 0.5, -4.0), (3.0, 2.5, 6.0), "dark"),
        ("root", (-1.2, 3.0, -12.0), (2.4, 2.4, 8.0), "black"),
        ("root", (-0.7, 3.6, -18.0), (1.4, 1.2, 1.0), "arc"),
        ("magazine", (-1.2, -5.0, -9.0), (2.4, 5.0, 2.4), "mid"),
    ],
    "launcher": [
        ("root", (-2.5, 0.0, -16.0), (5.0, 5.0, 12.0), "base"),
        ("root", (-2.0, 0.5, -20.0), (4.0, 4.0, 5.0), "mid"),
        ("root", (-1.6, 0.9, -21.0), (3.2, 3.2, 1.2), "accent"),
        ("root", (-1.5, -4.5, -3.0), (3.0, 4.5, 3.0), "rubber"),
        ("root", (-2.5, 4.0, -18.0), (5.0, 0.8, 10.0), "gold"),
        ("root", (-0.8, 5.0, -12.0), (1.6, 1.4, 3.0), "light"),
        ("magazine", (-1.2, -6.0, -10.0), (2.4, 6.0, 2.4), "mid"),
    ],
}

ANCHORS = {
    "handcannon": {"right": (0.0, -1.5, -2.0), "left": (1.0, -1.0, -4.5),
                   "sight": (0.0, 3.4, -9.0), "muzzle": (0.0, 2.5, -19.0),
                   "guard": (0.0, 1.0, -14.0), "mag": (0.0, -4.0, -8.0)},
    "rifle": {"right": (0.0, -2.0, -1.5), "left": (0.0, 0.5, -18.0),
              "sight": (0.0, 3.4, -11.0), "muzzle": (0.0, 2.5, -23.5),
              "guard": (0.0, 1.5, -18.0), "mag": (0.0, -4.5, -9.0)},
    "sniper": {"right": (0.0, -2.0, -1.5), "left": (0.0, 0.5, -22.0),
               "sight": (0.0, 5.2, -14.0), "muzzle": (0.0, 2.5, -29.5),
               "guard": (0.0, 1.5, -22.0), "mag": (0.0, -4.5, -9.0)},
    "launcher": {"right": (0.0, -2.0, -1.5), "left": (0.0, 2.0, -16.0),
                 "sight": (0.0, 5.2, -12.0), "muzzle": (0.0, 2.6, -21.0),
                 "guard": (0.0, 2.5, -16.0), "mag": (0.0, -4.0, -10.0)},
}


def write_json(path: str, payload) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def rpm_of(gun: dict) -> int:
    return max(1, min(1200, round(1200.0 / gun["tick"])))


def faces_of(material: str) -> dict:
    uv = PALETTE[material]
    return {face: {"uv": [uv[0], uv[1]], "texture_size": [64, 64]}
            for face in ("north", "east", "south", "west", "up", "down")}


def build_positioning(gun: dict) -> list:
    """TaCZ 必需/推荐的定位组（组名大小写敏感，不可改）。"""
    anchor = ANCHORS[gun["archetype"]]
    right, left = anchor["right"], anchor["left"]
    sight, muzzle = anchor["sight"], anchor["muzzle"]
    guard, mag = anchor["guard"], anchor["mag"]

    def hand(name: str, pivot: tuple, offset: tuple) -> dict:
        return {
            "name": name, "parent": "root", "pivot": list(pivot),
            "cubes": [{"origin": [pivot[0] + offset[0], pivot[1] + offset[1], pivot[2] + offset[2]],
                       "size": [4, 12, 4], "uv": faces_of("rubber")}],
        }

    return [
        {"name": "positioning", "parent": "root", "pivot": [0, 0, 0]},
        hand("lefthand_pos", left, (4, 0, -2)),
        hand("righthand_pos", right, (-8, 0, -2)),
        {"name": "idle_view", "parent": "positioning", "pivot": [0.0, 7.0, 13.0]},
        {"name": "iron_view", "parent": "positioning", "pivot": [sight[0], sight[1], sight[2] + 9.0]},
        {"name": "thirdperson_hand", "parent": "positioning",
         "pivot": [right[0], right[1], right[2]], "rotation": [0, 15, 0]},
        {"name": "ground", "parent": "positioning", "pivot": [0.0, -8.0, -8.0]},
        {"name": "fixed", "parent": "positioning", "pivot": [0.0, 0.0, -8.0], "rotation": [0, 90, 0]},
        {"name": "refit_view", "parent": "positioning", "pivot": [0.0, 4.0, 16.0]},
        {"name": "refit_muzzle_view", "parent": "positioning", "pivot": [muzzle[0], muzzle[1], muzzle[2] - 6.0]},
        {"name": "refit_stock_view", "parent": "positioning", "pivot": [0.0, 2.0, 10.0]},
        {"name": "refit_scope_view", "parent": "positioning", "pivot": [sight[0], sight[1] + 6.0, sight[2]]},
        {"name": "refit_extended_mag_view", "parent": "positioning", "pivot": [mag[0], mag[1] - 6.0, mag[2]]},
        {"name": "refit_grip_view", "parent": "positioning", "pivot": [guard[0], guard[1] - 6.0, guard[2]]},
        {"name": "refit_laser_view", "parent": "positioning", "pivot": [guard[0], guard[1], guard[2] - 4.0]},
    ]


def build_geo(gun: dict) -> dict:
    accent = ELEMENT_SLOT[gun["element"]]
    cubes_by_bone: dict[str, list] = {}
    for bone, origin, size, material in ARCHETYPES[gun["archetype"]]:
        material = accent if material == "accent" else material
        cubes_by_bone.setdefault(bone, []).append(
            {"origin": list(origin), "size": list(size), "uv": faces_of(material)})

    muzzle_z = -24.0 if gun["archetype"] != "launcher" else -21.0
    bones = [
        {"name": "root", "pivot": [0, 0, 0], "cubes": cubes_by_bone.get("root", [])},
        {"name": "magazine", "parent": "root", "pivot": [0, -4, -8], "cubes": []},
        {"name": "mag_standard", "parent": "magazine", "pivot": [0, -4, -8],
         "cubes": cubes_by_bone.get("magazine", [])},
        {"name": "sight", "parent": "root", "pivot": [0, 2.6, -12]},
        {"name": "sight_folded", "parent": "root", "pivot": [0, 2.6, -12]},
        {"name": "muzzle_default", "parent": "root", "pivot": [0, 2.5, muzzle_z]},
        {"name": "stock_default", "parent": "root", "pivot": [0, 1.0, 0.0]},
        {"name": "bullet_in_mag", "parent": "mag_standard", "pivot": [0, -4, -8]},
        {"name": "shell", "parent": "root", "pivot": [2.0, 2.0, -6.0]},
        {"name": "muzzle_flash", "parent": "root", "pivot": [0, 2.5, muzzle_z]},
    ]
    bones.extend(build_positioning(gun))

    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": f"geometry.{NS}_{gun['id']}",
                "texture_width": 64, "texture_height": 64,
                "visible_bounds_width": 6, "visible_bounds_height": 6,
                "visible_bounds_offset": [0, 0, 0],
            },
            "bones": bones,
        }],
    }


# ---------------------------------------------------------------- 数据文件（1.1.8）
def build_gun_data(gun: dict) -> dict:
    binding = TACZ_BINDING[gun["id"]]
    arch = gun["archetype"]
    reload_s = round(gun["reload"] / 20.0, 2)
    feed_empty = round(reload_s * 0.86, 2)
    spread = ARCH_SPREAD[arch]
    braced = round(spread * 0.25, 2)
    recoil = ARCH_RECOIL[arch]
    base_damage = gun["damage"]

    bullet = {
        "life": gun["life"],
        "bullet_amount": 1,
        "damage": base_damage,
        "tracer_count_interval": 0,
        "extra_damage": {
            "armor_ignore": 0.05,
            "head_shot_multiplier": 1.5,
            "damage_adjust": [
                {"distance": 0, "damage": base_damage},
                {"distance": ARCH_RANGE[arch] // 2, "damage": round(base_damage * 0.9, 2)},
                {"distance": ARCH_RANGE[arch], "damage": round(base_damage * 0.7, 2)},
                {"distance": "infinite", "damage": round(base_damage * 0.35, 2)},
            ],
        },
        "speed": gun["speed"],
        "gravity": gun["gravity"],
        "knockback": 0.05,
        "friction": 0.01,
        "ignite": {"entity": gun["element"] == "solar", "block": False},
        "ignite_entity_time": 2,
        "pierce": gun["pierce"],
    }
    if gun["explosion"] > 0:
        bullet["explosion"] = {
            "explode": True,
            "delay": 0,
            "radius": gun["explosion"],
            "damage": round(base_damage * 0.6, 2),
            "knockback": False,
            "destroy_block": False,
        }

    return {
        "ammo": binding["ammo"],
        "ammo_amount": gun["mag"],
        "can_crawl": True,
        "can_slide": True,
        "bolt": "closed_bolt",
        "rpm": rpm_of(gun),
        "bullet": bullet,
        "fire_sound": {"fire_multiplier": 1.0, "silence_multiplier": 1.0},
        "reload": {
            "type": "magazine",
            "infinite": False,
            "feed": {"empty": feed_empty, "tactical": round(feed_empty * 0.78, 2)},
            "cooldown": {"empty": reload_s, "tactical": round(reload_s * 0.78, 2)},
        },
        "draw_time": 0.35,
        "put_away_time": 0.4,
        "aim_time": 0.2,
        "sprint_time": 0.3,
        "weight": ARCH_WEIGHT[arch],
        "movement_speed": {"base": 0.0, "aim": -0.2, "reload": -0.15},
        "fire_mode": ["auto", "semi"] if gun["auto"] else ["semi"],
        "crawl_recoil_multiplier": 0.5,
        "recoil": {
            "pitch": [
                {"time": 0, "value": [recoil, recoil]},
                {"time": 0.1, "value": [recoil, recoil]},
                {"time": 0.45, "value": [round(-recoil * 0.25, 3), round(-recoil * 0.25, 3)]},
                {"time": 0.6, "value": [0, 0]},
            ],
            "yaw": [
                {"time": 0, "value": [round(-recoil * 0.3, 3), round(recoil * 0.2, 3)]},
                {"time": 0.35, "value": [0, 0]},
            ],
        },
        "hurt_bob_tweak_multiplier": 0.05,
        "inaccuracy": {
            "stand": spread,
            "move": round(spread * 2.1, 2),
            "sneak": braced,
            "lie": round(braced * 0.8, 2),
            "aim": round(braced * 0.5, 2),
        },
        "melee": {
            "distance": 1,
            "cooldown": 0.7,
            "default": {
                "animation_type": "melee_push" if arch in ("handcannon", "launcher") else "melee_stock",
                "distance": 1,
                "range_angle": 40,
                "cooldown": 0,
                "damage": 1,
                "knockback": 0.5,
                "prep": 0.1,
            },
        },
        # 当前模型没有 muzzle_pos / scope_pos 等配件定位组，先关闭配件槽
        "allow_attachment_types": [],
    }


def build_gun_display(gun: dict) -> dict:
    binding = TACZ_BINDING[gun["id"]]
    stem = binding["stem"]
    display = {
        "model": f"{NS}:gun/{gun['id']}_geo",
        "texture": f"{NS}:gun/uv/{gun['id']}",
        "slot": f"{NS}:gun/slot/{gun['id']}",
        "ammo_count_style": "normal",
        "damage_style": "per_projectile",
        # 动画/状态机复用 TaCZ 默认包（跨枪包引用是官方支持的）
        "animation": f"tacz:{stem}",
        "state_machine": f"tacz:{stem}_state_machine",
        "use_default_animation": binding["default_anim"],
        "third_person_animation": "default",
        "show_crosshair": False,
        "transform": {"scale": {"thirdperson": [0.6, 0.6, 0.6],
                                "ground": [0.6, 0.6, 0.6],
                                "fixed": [1.0, 1.0, 1.0]}},
        "muzzle_flash": {"texture": "tacz:flash/common_muzzle_flash", "scale": 0.75},
        "iron_zoom": binding["iron_zoom"],
        "zoom_model_fov": binding["zoom_fov"],
        "ammo": {"tracer_color": binding["tracer"]},
        "sounds": {
            key: f"tacz:{stem}/{stem}_{key}"
            for key in ("shoot", "shoot_3p", "draw", "put_away", "silence", "silence_3p")
        },
    }
    if binding["hud"]:
        display["hud"] = f"tacz:gun/hud/{stem}"
    return display


def build_gun_index(gun: dict) -> dict:
    return {
        "name": f"gun.{NS}.{gun['id']}.name",
        "display": f"{NS}:{gun['id']}_display",
        "data": f"{NS}:{gun['id']}_data",
        "tooltip": f"gun.{NS}.{gun['id']}.desc",
        "type": gun["type"],
        "sort": gun["sort"],
    }


def build_recipe(gun: dict) -> dict:
    materials = [{"item": {"tag": tag}, "count": count}
                 for tag, count in TACZ_BINDING[gun["id"]]["materials"]]
    return {
        "materials": materials,
        "result": {"type": "gun", "id": f"{NS}:{gun['id']}"},
        "type": "tacz:gun_smith_table_crafting",
    }


# ---------------------------------------------------------------- 贴图 / 语言 / 元数据
def build_textures() -> None:
    from PIL import Image

    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    pixels = img.load()
    for name, (ox, oy) in PALETTE.items():
        base = PALETTE_RGB[name]
        for y in range(16):
            for x in range(16):
                noise = ((x * 7 + y * 13) % 5) - 2
                pixels[ox + x, oy + y] = (
                    max(0, min(255, base[0] + noise)),
                    max(0, min(255, base[1] + noise)),
                    max(0, min(255, base[2] + noise)),
                    255,
                )
    for gun in GUNS:
        path = os.path.join(PACK_ROOT, "assets", NS, "textures", "gun", "uv", f"{gun['id']}.png")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        img.save(path)


def build_slot_icons() -> None:
    from PIL import Image

    src_dir = os.path.join(ROOT, "src", "main", "resources", "assets", "destinyarsenal",
                           "textures", "item")
    for gun in GUNS:
        src = os.path.join(src_dir, f"{gun['id']}.png")
        dst = os.path.join(PACK_ROOT, "assets", NS, "textures", "gun", "slot", f"{gun['id']}.png")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        with Image.open(src) as image:
            image.convert("RGBA").resize((32, 32), Image.NEAREST).save(dst)


PERK_DESC = {
    "gjallarhorn": "Wolfpack Rounds: scatters six homing sub-munitions on impact.",
    "last_word": "Desperado: every hit stacks damage. Best used from the hip.",
    "fatebringer": "Firefly: precision kills detonate the target.",
    "thunderlord": "Lightning Rounds: every third consecutive hit calls a thunderstorm.",
    "sunshot": "Sunblast: hits cause a small solar explosion and set targets alight.",
    "izanagis_burden": "Honed Edge: a heavy single shot meant for boss damage.",
    "mountaintop": "Micro-Missile: tiny blast, huge recoil. Rocket jump away.",
    "graviton_lance": "Black Hole: kills leave a void singularity behind.",
}
PERK_DESC_ZH = {
    "gjallarhorn": "狼群弹：命中后撒出 6 枚追踪子弹药。",
    "last_word": "亡命之徒：每次命中叠加伤害，腰射最顺手。",
    "fatebringer": "萤火：精准击杀会引爆目标。",
    "thunderlord": "闪电弹：每连续三次命中召唤雷暴。",
    "sunshot": "日爆：命中引发小型太阳爆炸并点燃目标。",
    "izanagis_burden": "磨砺之刃：为打 Boss 准备的重型单发。",
    "mountaintop": "微型导弹：爆炸小、后坐力大，可以火箭跳。",
    "graviton_lance": "黑洞：击杀后留下虚空奇点。",
}


def build_lang() -> None:
    en = {
        f"pack.{NS}.name": "Destiny 2 Arsenal (TaCZ)",
        f"pack.{NS}.desc": "Eight Destiny 2 exotics rebuilt for TaCZ 1.1.8.",
    }
    zh = {
        f"pack.{NS}.name": "命运 2 军械库（TaCZ 版）",
        f"pack.{NS}.desc": "把《命运 2》的 8 把异域武器做进 TaCZ 1.1.8。",
    }
    for gun in GUNS:
        en[f"gun.{NS}.{gun['id']}.name"] = gun["en"]
        zh[f"gun.{NS}.{gun['id']}.name"] = gun["zh"]
        en[f"gun.{NS}.{gun['id']}.desc"] = PERK_DESC[gun["id"]]
        zh[f"gun.{NS}.{gun['id']}.desc"] = PERK_DESC_ZH[gun["id"]]

    for locale, table in (("en_us", en), ("zh_cn", zh)):
        write_json(os.path.join(PACK_ROOT, "assets", NS, "lang", f"{locale}.json"),
                   dict(sorted(table.items())))


def build_meta() -> None:
    write_json(os.path.join(PACK_ROOT, "gunpack.meta.json"),
               {"namespace": NS, "dependencies": {"tacz": "[1.1.4,)"}})
    write_json(os.path.join(PACK_ROOT, "assets", NS, "gunpack_info.json"), {
        "version": "1.2.0",
        "name": f"pack.{NS}.name",
        "desc": f"pack.{NS}.desc",
        "license": "MIT",
        "authors": ["Destiny 2 Arsenal"],
        "date": "2026-11-14",
        "url": "https://github.com/example/destiny2-arsenal",
    })


def main() -> None:
    for gun in GUNS:
        write_json(os.path.join(PACK_ROOT, "assets", NS, "geo_models", "gun", f"{gun['id']}_geo.json"),
                   build_geo(gun))
        write_json(os.path.join(PACK_ROOT, "assets", NS, "display", "guns", f"{gun['id']}_display.json"),
                   build_gun_display(gun))
        write_json(os.path.join(PACK_ROOT, "data", NS, "index", "guns", f"{gun['id']}.json"),
                   build_gun_index(gun))
        write_json(os.path.join(PACK_ROOT, "data", NS, "data", "guns", f"{gun['id']}_data.json"),
                   build_gun_data(gun))
        write_json(os.path.join(PACK_ROOT, "data", NS, "recipes", "gun", f"{gun['id']}.json"),
                   build_recipe(gun))

    build_textures()
    build_slot_icons()
    build_lang()
    build_meta()

    files = sum(len(f) for _d, _s, f in os.walk(PACK_ROOT))
    print(f"TaCZ 1.1.8 枪包已生成：{len(GUNS)} 把枪 / 共 {files} 个文件")
    print(f"输出目录：{PACK_ROOT}")


if __name__ == "__main__":
    main()
