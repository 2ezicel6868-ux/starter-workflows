#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
《命运 2》军械库 —— 物品贴图生成器。

用途：生成 src/main/resources/assets/destinyarsenal/textures/item/*.png 与 icon.png。
全部是手写的 16x16 像素布局（每把枪都是一组矩形），保证风格统一、可维护。

用法：
    python tools/gen_textures.py
依赖：
    Pillow（pip install pillow）
"""

from __future__ import annotations

import os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ITEM_OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "destinyarsenal", "textures", "item")
ICON_OUT = os.path.join(ROOT, "src", "main", "resources", "assets", "destinyarsenal", "icon.png")
DOCS_OUT = os.path.join(ROOT, "docs")

# ---------------------------------------------------------------- 调色板
DARK = (32, 35, 42, 255)
BASE = (56, 62, 74, 255)
MID = (104, 113, 128, 255)
LIGHT = (176, 186, 200, 255)
WHITE = (232, 238, 246, 255)
GOLD = (208, 170, 74, 255)
GOLD_DARK = (140, 108, 40, 255)

ELEMENT = {
    "kinetic": (216, 222, 230, 255),
    "solar": (255, 122, 47, 255),
    "arc": (111, 211, 255, 255),
    "void": (178, 105, 255, 255),
}


def rect(draw, x, y, w, h, color):
    """按 16x16 网格画矩形（含边界）。"""
    draw.rectangle([x, y, x + w - 1, y + h - 1], fill=color)


def gun_hand_cannon(draw, accent, trim):
    """手炮：短粗，左下手柄，右上枪管。"""
    rect(draw, 7, 6, 6, 2, MID)        # 枪管
    rect(draw, 13, 6, 1, 2, accent)    # 枪口
    rect(draw, 4, 5, 5, 4, BASE)       # 机匣
    rect(draw, 5, 7, 3, 2, DARK)       # 转轮
    rect(draw, 8, 5, 3, 1, accent)     # 顶部能量槽
    rect(draw, 4, 4, 2, 1, MID)        # 击锤
    rect(draw, 3, 8, 3, 5, DARK)       # 握把
    rect(draw, 3, 8, 3, 1, trim)       # 握把金饰
    rect(draw, 6, 9, 2, 1, DARK)       # 扳机护圈
    rect(draw, 11, 5, 1, 1, LIGHT)     # 准星


def gun_auto_rifle(draw, accent, trim):
    """自动步枪：长机匣 + 弹匣。"""
    rect(draw, 2, 6, 7, 3, BASE)       # 机匣
    rect(draw, 9, 7, 6, 1, MID)        # 枪管
    rect(draw, 15, 7, 1, 1, accent)    # 枪口
    rect(draw, 1, 7, 1, 2, DARK)       # 枪托
    rect(draw, 4, 9, 2, 4, DARK)       # 握把
    rect(draw, 6, 9, 2, 4, MID)        # 弹匣
    rect(draw, 5, 4, 4, 2, DARK)       # 瞄具
    rect(draw, 5, 4, 1, 1, accent)     # 瞄具光点
    rect(draw, 3, 6, 4, 1, trim)       # 上机匣饰条


def gun_pulse_rifle(draw, accent, trim):
    """脉冲步枪：中等长度 + 三点能量指示。"""
    rect(draw, 3, 6, 6, 3, BASE)
    rect(draw, 9, 7, 5, 1, MID)
    rect(draw, 14, 7, 1, 1, accent)
    rect(draw, 2, 7, 1, 2, DARK)
    rect(draw, 4, 9, 2, 4, DARK)
    rect(draw, 6, 9, 2, 3, MID)
    rect(draw, 3, 5, 3, 1, trim)
    for i in range(3):
        rect(draw, 10 + i * 2, 6, 1, 1, accent)


def gun_sniper(draw, accent, trim):
    """狙击枪：超长枪管 + 大倍镜。"""
    rect(draw, 3, 6, 6, 3, BASE)
    rect(draw, 9, 7, 7, 1, MID)
    rect(draw, 15, 7, 1, 1, accent)
    rect(draw, 1, 7, 2, 2, DARK)
    rect(draw, 4, 9, 2, 4, DARK)
    rect(draw, 5, 3, 5, 2, DARK)       # 倍镜
    rect(draw, 10, 3, 1, 2, accent)    # 镜片
    rect(draw, 6, 3, 1, 1, LIGHT)
    rect(draw, 6, 5, 2, 1, DARK)       # 镜桥
    rect(draw, 13, 8, 1, 3, DARK)      # 两脚架


def gun_machine_gun(draw, accent, trim):
    """机枪：长枪管 + 弹鼓。"""
    rect(draw, 2, 6, 6, 3, BASE)
    rect(draw, 8, 7, 7, 1, MID)
    rect(draw, 15, 7, 1, 1, accent)
    rect(draw, 1, 7, 1, 2, DARK)
    rect(draw, 4, 9, 3, 4, DARK)       # 弹鼓
    rect(draw, 4, 9, 3, 1, MID)
    rect(draw, 7, 9, 1, 4, DARK)
    rect(draw, 9, 6, 4, 1, accent)     # 电弧导轨
    rect(draw, 3, 6, 3, 1, trim)


def gun_rocket_launcher(draw, accent, trim):
    """火箭筒：粗发射管 + 尾翼。"""
    rect(draw, 3, 5, 9, 4, BASE)       # 发射管
    rect(draw, 4, 6, 7, 2, DARK)       # 内膛
    rect(draw, 12, 4, 3, 6, MID)       # 前口
    rect(draw, 13, 5, 1, 4, accent)    # 口部能量
    rect(draw, 2, 4, 2, 1, MID)        # 尾翼
    rect(draw, 2, 9, 2, 1, MID)
    rect(draw, 4, 9, 2, 4, DARK)       # 握把
    rect(draw, 6, 9, 1, 2, DARK)       # 扳机
    rect(draw, 5, 5, 3, 1, trim)       # 饰条


def gun_grenade_launcher(draw, accent, trim):
    """榴弹发射器：短粗 + 鼓形弹仓。"""
    rect(draw, 4, 7, 8, 3, BASE)
    rect(draw, 5, 8, 6, 1, DARK)
    rect(draw, 12, 6, 3, 5, MID)
    rect(draw, 13, 7, 1, 3, accent)
    rect(draw, 4, 10, 2, 4, DARK)
    rect(draw, 6, 4, 3, 2, DARK)       # 瞄具
    rect(draw, 5, 4, 1, 1, accent)
    rect(draw, 8, 7, 2, 1, trim)


WEAPONS = {
    # id: (绘制函数, 元素)
    "gjallarhorn": (gun_rocket_launcher, "solar"),
    "last_word": (gun_hand_cannon, "kinetic"),
    "fatebringer": (gun_hand_cannon, "kinetic"),
    "thunderlord": (gun_machine_gun, "arc"),
    "sunshot": (gun_hand_cannon, "solar"),
    "izanagis_burden": (gun_sniper, "kinetic"),
    "mountaintop": (gun_grenade_launcher, "kinetic"),
    "graviton_lance": (gun_pulse_rifle, "void"),
}

# 每把枪的「金饰」与握把配色略有差异，避免 8 张图看起来像同一把
TRIM = {
    "gjallarhorn": (222, 178, 70, 255),
    "last_word": (196, 160, 60, 255),
    "fatebringer": (168, 176, 190, 255),
    "thunderlord": (150, 200, 235, 255),
    "sunshot": (232, 120, 60, 255),
    "izanagis_burden": (200, 168, 72, 255),
    "mountaintop": (150, 200, 235, 255),
    "graviton_lance": (186, 130, 255, 255),
}


def make_item(name: str) -> Image.Image:
    draw_fn, element = WEAPONS[name]
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw_fn(draw, ELEMENT[element], TRIM[name])
    return img


def make_icon() -> Image.Image:
    """128x128 的 mod 图标：深色底 + 金色准星徽记 + 交叉武器剪影。"""
    size = 128
    img = Image.new("RGBA", (size, size), (14, 16, 22, 255))
    draw = ImageDraw.Draw(img)

    # 背景渐层（用横向叠色模拟）
    for i in range(size):
        shade = int(14 + 22 * (i / size))
        draw.line([(0, i), (size, i)], fill=(shade, shade + 3, shade + 10, 255))

    # 金色外环
    draw.ellipse([12, 12, size - 13, size - 13], outline=GOLD, width=4)
    draw.ellipse([22, 22, size - 23, size - 23], outline=GOLD_DARK, width=2)

    # 准星：十字 + 中心菱形
    cx = cy = size // 2
    draw.line([(cx, 30), (cx, 98)], fill=GOLD, width=3)
    draw.line([(30, cy), (98, cy)], fill=GOLD, width=3)
    draw.polygon([(cx, cy - 14), (cx + 14, cy), (cx, cy + 14), (cx - 14, cy)],
                 outline=GOLD, fill=(30, 26, 18, 255))

    # 交叉的步枪剪影
    rifle = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    rd = ImageDraw.Draw(rifle)
    rd.rectangle([18, 60, 108, 68], fill=(180, 190, 205, 210))
    rd.rectangle([24, 68, 34, 86], fill=(120, 128, 145, 210))
    rd.rectangle([96, 56, 110, 62], fill=(230, 235, 245, 210))
    for angle, alpha in ((-38, 255), (38, 255)):
        rotated = rifle.rotate(angle, resample=Image.BICUBIC, center=(cx, cy))
        img.paste(rotated, (0, 0), rotated)

    # 底部小字色块（不依赖字体，避免缺字体时崩）
    draw.rectangle([44, 106, 84, 110], fill=GOLD)
    return img


def make_preview(images: dict) -> Image.Image:
    """把 16x16 拼成 8 倍放大的预览图，方便肉眼检查。"""
    scale = 8
    cell = 16 * scale
    pad = 10
    cols = 4
    rows = 2
    width = cols * cell + (cols + 1) * pad
    height = rows * cell + (rows + 1) * pad + 22
    sheet = Image.new("RGBA", (width, height), (26, 28, 34, 255))
    try:
        font = ImageFont.load_default()
    except Exception:  # pragma: no cover
        font = None
    names = list(images.keys())
    for index, name in enumerate(names):
        col = index % cols
        row = index // cols
        x = pad + col * (cell + pad)
        y = pad + row * (cell + pad)
        sheet.alpha_composite(images[name].resize((cell, cell), Image.NEAREST), (x, y))
        if font is not None:
            draw = ImageDraw.Draw(sheet)
            draw.text((x, y + cell + 2), name, fill=(190, 198, 210, 255), font=font)
    return sheet


def main() -> None:
    os.makedirs(ITEM_OUT, exist_ok=True)
    os.makedirs(DOCS_OUT, exist_ok=True)

    images = {}
    for name in WEAPONS:
        img = make_item(name)
        img.save(os.path.join(ITEM_OUT, name + ".png"))
        images[name] = img
        print("texture:", name + ".png")

    icon = make_icon()
    icon.save(ICON_OUT)
    print("icon:", ICON_OUT)

    preview = make_preview(images)
    preview.save(os.path.join(DOCS_OUT, "textures-preview.png"))
    print("preview:", os.path.join(DOCS_OUT, "textures-preview.png"))


if __name__ == "__main__":
    main()
