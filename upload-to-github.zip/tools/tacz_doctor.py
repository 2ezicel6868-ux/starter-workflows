#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TaCZ 枪包体检 —— 读实例日志，判断枪包有没有被识别、有没有报错。

用法：
    python tools/tacz_doctor.py
    python tools/tacz_doctor.py --instance "E:/mc/.../逆转未来2.3.3"

退出码：0 = 枪包已被识别且无报错；1 = 有问题。
"""

from __future__ import annotations

import glob
import os
import re
import sys
import zipfile

DEFAULT_INSTANCE = r"E:\mc\libs\.minecraft\versions\逆转未来2.3.3"
MY_NS = "d2arsenal"
MY_GUNS = ["gjallarhorn", "last_word", "fatebringer", "thunderlord",
           "sunshot", "izanagis_burden", "mountaintop", "graviton_lance"]

problems: list[str] = []
notes: list[str] = []


def find_log(instance: str) -> str | None:
    path = os.path.join(instance, "logs", "latest.log")
    if os.path.isfile(path):
        return path
    candidates = sorted(glob.glob(os.path.join(instance, "logs", "*.log")), key=os.path.getmtime)
    return candidates[-1] if candidates else None


def read_text(path: str) -> str:
    for encoding in ("utf-8", "gbk", "latin-1"):
        try:
            with open(path, "r", encoding=encoding, errors="strict") as handle:
                return handle.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as handle:
        return handle.read()


def scan_packs(instance: str) -> dict[str, tuple[str, int]]:
    """读 tacz/ 下所有 zip，返回 {文件名: (命名空间, 枪械数量)}。"""
    tacz_dir = os.path.join(instance, "tacz")
    result: dict[str, tuple[str, int]] = {}
    if not os.path.isdir(tacz_dir):
        problems.append(f"找不到枪包目录: {tacz_dir}")
        return result
    for name in sorted(os.listdir(tacz_dir)):
        full = os.path.join(tacz_dir, name)
        if not name.lower().endswith(".zip"):
            continue
        try:
            with zipfile.ZipFile(full) as archive:
                names = archive.namelist()
                meta = "gunpack.meta.json" in names
                namespace = "?"
                if meta:
                    raw = archive.read("gunpack.meta.json").decode("utf-8", "replace")
                    match = re.search(r'"namespace"\s*:\s*"([^"]+)"', raw)
                    if match:
                        namespace = match.group(1)
                guns = [n for n in names if re.search(r"/index/guns/[^/]+\.json$", n)]
                result[name] = (namespace, len(guns))
        except zipfile.BadZipFile:
            problems.append(f"{name} 不是合法 zip")
    return result


def main() -> int:
    instance = DEFAULT_INSTANCE
    if "--instance" in sys.argv:
        instance = sys.argv[sys.argv.index("--instance") + 1]

    print(f"实例：{instance}")
    if not os.path.isdir(instance):
        print(f"[失败] 实例目录不存在：{instance}")
        return 1

    packs = scan_packs(instance)
    print(f"\n=== tacz/ 里的 zip 枪包（{len(packs)} 个）===")
    for name, (namespace, gun_count) in packs.items():
        mark = "  <== 本枪包" if namespace == MY_NS else ""
        print(f"  {name}\n      命名空间={namespace}  枪械={gun_count}{mark}")

    # 命名空间冲突
    seen: dict[str, str] = {}
    for name, (namespace, _count) in packs.items():
        if namespace in seen:
            problems.append(f"命名空间 {namespace} 重复：{seen[namespace]} 与 {name}")
        seen[namespace] = name

    if MY_NS not in seen:
        problems.append(f"tacz/ 里没有找到命名空间为 {MY_NS} 的枪包")
    else:
        notes.append(f"已找到命名空间 {MY_NS}（{seen[MY_NS]}）")

    # 日志检查
    log = find_log(instance)
    print(f"\n=== 日志：{log} ===")
    if not log:
        problems.append("找不到日志文件")
    else:
        text = read_text(log)
        scan_start = text.rfind("Start scanning for gun packs")
        if scan_start < 0:
            problems.append("日志里没有 TaCZ 的枪包扫描记录（游戏可能没进到主界面过）")
        else:
            block = text[scan_start:scan_start + 4000].splitlines()
            listed = [line for line in block if re.search(r"Main namespace", line)]
            count_line = next((line for line in block if "possible gunpack" in line), "")
            print(f"  {count_line.strip()}")
            for line in listed[:12]:
                print(f"  {line.strip()}")
            if MY_NS in " ".join(listed):
                notes.append("日志中已识别 d2arsenal 枪包")
            else:
                problems.append("日志的枪包列表里没有 d2arsenal —— 装好后还没重启过游戏，或者 zip 没被读取")

        # 报错行
        bad = [line.strip() for line in text.splitlines()
               if re.search(r"(ERROR|Exception|Failed|Caused by)", line)
               and re.search(r"(tacz|gunpack|" + MY_NS + ")", line, re.I)]
        if bad:
            print("\n  --- 与枪包相关的报错（最多 10 条）---")
            for line in bad[-10:]:
                print(f"  {line}")
            problems.append(f"日志里有 {len(bad)} 条与枪包相关的报错")
        else:
            notes.append("日志里没有与枪包相关的报错")

    print("\n=== 结论 ===")
    for note in notes:
        print(f"  [OK]   {note}")
    if problems:
        for problem in problems:
            print(f"  [问题] {problem}")
        print("\n建议：确认 zip 放在 <实例>/tacz/ 根目录、压缩包内 gunpack.meta.json 位于最外层，"
              "然后重启游戏再看一次。")
        return 1
    print("\n  一切正常：枪包已被 TaCZ 识别，进游戏用 /tacz reload 或创造物品栏确认。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
