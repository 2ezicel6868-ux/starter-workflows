#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TaCZ 枪包模型预览：把 geo 里的方块做等距投影，渲染成一张对比图。

用途：不启动游戏也能肉眼检查「方块搭出来的枪像不像枪」。
输出：docs/tacz-models-preview.png

用法：python tools/preview_models.py
"""

from __future__ import annotations

import json
import math
import os

from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK = os.path.join(ROOT, "tacz_pack", "d2arsenal_gun_pack")
NS = "d2arsenal"
OUT = os.path.join(ROOT, "docs", "tacz-models-preview.png")

COLORS = {
    "dark": (32, 35, 42),
    "base": (56, 62, 74),
    "mid": (104, 113, 128),
    "light": (176, 186, 200),
    "gold": (208, 170, 74),
    "solar": (255, 122, 47),
    "arc": (111, 211, 255),
    "void": (178, 105, 255),
    "kinetic": (216, 222, 230),
    "black": (18, 20, 24),
    "steel": (140, 150, 165),
    "rubber": (44, 46, 52),
}
# 图集里每个色块左上角 -> 颜色名（与 gen_tacz_pack.py 的 PALETTE 对应）
UV_COLOR = {}
for name, (x, y) in {
    "dark": (0, 0), "base": (16, 0), "mid": (32, 0), "light": (48, 0),
    "gold": (0, 16), "solar": (16, 16), "arc": (32, 16), "void": (48, 16),
    "kinetic": (0, 32), "black": (16, 32), "steel": (32, 32), "rubber": (48, 32),
}.items():
    UV_COLOR[(x, y)] = name

SCALE = 2.6
CELL = 150
COLS = 4


def iso(x: float, y: float, z: float) -> tuple[float, float]:
    return (x - z) * 0.866, -(y + (x + z) * 0.5)


def shade(color, factor):
    return tuple(max(0, min(255, int(c * factor))) for c in color)


def draw_box(draw, origin, size, color, ox, oy):
    x, y, z = origin
    sx, sy, sz = size
    # 八个顶点
    p = lambda dx, dy, dz: iso(x + dx, y + dy, z + dz)  # noqa: E731
    corners = {
        "top": [p(0, sy, 0), p(sx, sy, 0), p(sx, sy, sz), p(0, sy, sz)],
        "left": [p(0, 0, sz), p(0, sy, sz), p(0, sy, 0), p(0, 0, 0)],
        "front": [p(0, 0, 0), p(0, sy, 0), p(sx, sy, 0), p(sx, 0, 0)],
    }
    faces = [
        ("top", shade(color, 1.18)),
        ("left", shade(color, 0.72)),
        ("front", shade(color, 0.95)),
    ]
    for _name, face_color in faces:
        pass
    for name, face_color in faces:
        pts = [(ox + px * SCALE, oy + py * SCALE) for px, py in corners[name]]
        draw.polygon(pts, fill=face_color, outline=shade(face_color, 0.8))


# 这些组的方块不参与渲染（TaCZ 里会被替换成玩家手部/仅作定位），预览时跳过
SKIP_RENDER = {
    "lefthand_pos", "righthand_pos", "positioning",
    "idle_view", "iron_view", "ground", "fixed", "thirdperson_hand",
}
# 定位组标记颜色
PIVOT_MARKERS = {
    "righthand_pos": (255, 90, 90),
    "lefthand_pos": (110, 235, 130),
    "idle_view": (255, 220, 90),
    "iron_view": (110, 220, 255),
    "thirdperson_hand": (255, 150, 60),
    "ground": (170, 170, 180),
    "fixed": (200, 140, 255),
}


def render(geo_path: str) -> Image.Image:
    with open(geo_path, "r", encoding="utf-8") as handle:
        geo = json.load(handle)
    geometry = geo["minecraft:geometry"][0]
    boxes = []
    pivots = []
    for bone in geometry.get("bones", []):
        name = bone.get("name", "")
        if name in PIVOT_MARKERS and bone.get("pivot"):
            pivots.append((bone["pivot"], PIVOT_MARKERS[name]))
        if name in SKIP_RENDER:
            continue
        for cube in bone.get("cubes", []):
            face = cube["uv"]["north"]
            color_name = UV_COLOR.get(tuple(face["uv"]), "base")
            boxes.append((cube["origin"], cube["size"], COLORS[color_name]))

    # 深度排序：z 越靠前（越负）越晚画
    boxes.sort(key=lambda item: (item[0][2] + item[0][0]))

    img = Image.new("RGB", (CELL, CELL), (24, 26, 32))
    draw = ImageDraw.Draw(img)
    ox, oy = CELL / 2, CELL / 2
    for origin, size, color in boxes:
        draw_box(draw, origin, size, color, ox, oy)
    # 定位组枢纽点
    for pivot, color in pivots:
        px, py = iso(pivot[0], pivot[1], pivot[2])
        cx, cy = ox + px * SCALE, oy + py * SCALE
        draw.ellipse([cx - 3, cy - 3, cx + 3, cy + 3], outline=color, width=2)
    return img


def main() -> None:
    geo_dir = os.path.join(PACK, "assets", NS, "geo_models", "gun")
    names = sorted(name for name in os.listdir(geo_dir) if name.endswith("_geo.json"))
    rows = math.ceil(len(names) / COLS)
    sheet = Image.new("RGB", (COLS * CELL, rows * CELL), (18, 20, 26))
    for index, name in enumerate(names):
        tile = render(os.path.join(geo_dir, name))
        col, row = index % COLS, index // COLS
        sheet.paste(tile, (col * CELL, row * CELL))
    sheet = sheet.resize((sheet.width * 2, sheet.height * 2), Image.LANCZOS)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    sheet.save(OUT)
    print("预览已生成:", OUT)


if __name__ == "__main__":
    main()
