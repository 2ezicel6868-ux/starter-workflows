#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
把 TaCZ 枪包打成发行包：.zip 与 .jar（两者内容完全相同，只是扩展名不同）。

注意：TaCZ 枪包**不是** Forge/NeoForge 模组，不要放进 mods/。
     它要放进实例根目录的 tacz/ 里（文件夹或压缩包都行）。

产出：
  dist/d2arsenal_gun_pack.zip
  dist/d2arsenal_gun_pack.jar

用法：python tools/package_pack.py
"""

from __future__ import annotations

import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PACK = os.path.join(ROOT, "tacz_pack", "d2arsenal_gun_pack")
DIST = os.path.join(ROOT, "dist")
BASE = "d2arsenal_gun_pack"

# 固定时间戳，保证同样输入产出同样字节（可复现构建）
FIXED_TIME = (2026, 11, 14, 0, 0, 0)


def collect(root: str) -> list[tuple[str, str]]:
    """返回 (文件绝对路径, 压缩包内路径) 列表，压缩包内为「枪包根目录即顶层」。"""
    entries = []
    for base, dirs, files in os.walk(root):
        dirs.sort()
        for name in sorted(files):
            full = os.path.join(base, name)
            relative = os.path.relpath(full, root).replace(os.sep, "/")
            entries.append((full, relative))
    return entries


def write_archive(path: str, entries: list[tuple[str, str]]) -> None:
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for full, arcname in entries:
            info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, "rb") as handle:
                archive.writestr(info, handle.read())


def verify(path: str) -> None:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if "gunpack.meta.json" not in names:
            raise SystemExit(f"{os.path.basename(path)}: gunpack.meta.json 不在压缩包根目录")
        if any(name.startswith(BASE + "/") for name in names):
            raise SystemExit(f"{os.path.basename(path)}: 出现了多余的外层目录 {BASE}/")
        bad = archive.testzip()
        if bad:
            raise SystemExit(f"{os.path.basename(path)}: 压缩包损坏 -> {bad}")
        print(f"  {os.path.basename(path)}: {len(names)} 个条目，根目录含 gunpack.meta.json [OK]")


def main() -> int:
    if not os.path.isdir(PACK):
        print("找不到枪包目录，请先运行 python tools/gen_tacz_pack.py")
        return 1

    os.makedirs(DIST, exist_ok=True)
    entries = collect(PACK)

    targets = [
        os.path.join(DIST, BASE + ".zip"),
        os.path.join(DIST, BASE + ".jar"),
    ]
    for path in targets:
        write_archive(path, entries)

    print("发行包已生成：")
    for path in targets:
        verify(path)
    print(f"输出目录：{DIST}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
