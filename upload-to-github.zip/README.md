# 命运 2 军械库 · Destiny 2 Arsenal

把《命运 2》的 8 把**异域武器**搬进 Minecraft **1.20.1 / Forge**，并可与 **TaCZ 1.1.8** 同装共存。

弹匣、换弹、元素伤害、精准命中、专属特性全部实现；**不使用 Mixin、不新增实体、不新增网络包、不破坏地形**。

![物品贴图预览](docs/textures-preview.png)

> **一个 jar 搞定 mod + TaCZ 枪包**
> 这个 jar 里同时装了：
> 1. **Java 版武器逻辑**（8 把枪的特性和弹道，走原版物品）；
> 2. **一份完整的 TaCZ 枪包**（`tacz_bundle/d2arsenal_gun_pack.zip`），首次启动自动释放到
>    `<游戏目录>/tacz/`，于是 TaCZ 那边也能看到同样 8 把枪（带 3D 模型与开镜）。
>
> 两套武器各自独立（命名空间 `destinyarsenal:` 与 TaCZ 的 `d2arsenal:`），互不干扰。

---

## 一、这个 mod 有什么

| 关键词 | 说明 |
| --- | --- |
| 8 把异域武器 | 每把一个独立机制，不是换个名字的剑 |
| 真弹匣 | 耐久条就是弹药条，打空必须换弹（有换弹动作音效） |
| 元素系统 | 动能 / 烈日 / 电弧 / 虚空，各自对应粒子与配色 |
| 精准命中 | 命中点高于目标 72% 身高算爆头，按武器倍率加成 |
| 距离衰减 | 超出射程伤害下降，但不会归零 |
| 命中反馈 | 枪口焰、命中粒子、元素爆炸、分类型开火音效 |
| 特性系统 | 狼群弹、亡命叠层、萤火、雷暴、日爆、蓄力、火箭跳、黑洞 |
| 中英双语 | `zh_cn` / `en_us` 完整语言文件 |
| 可调平衡 | 所有数值集中在 `WeaponCatalog.java` 一个文件 |
| 与 TaCZ 共存 | 命名空间/物品栏/按键/渲染全部互不干扰 |
| 附带 TaCZ 枪包 | `tacz_pack/` 里有 8 把枪 + 4 种弹药的完整 TaCZ 枪包（3D 模型/开镜/配件由 TaCZ 提供） |

---

## 二、武器一览

| 武器 | 类型 | 元素 | 弹匣 | 特性 |
| --- | --- | --- | --- | --- |
| **狼嚎** Gjallarhorn | 火箭发射器 | 烈日 | 1 | 命中后撒出 6 枚追踪狼群弹 |
| **最后的话语** The Last Word | 手炮 | 动能 | 8 | 命中叠「亡命」，每层 +6% 伤害（上限 5 层） |
| **命运终结者** Fatebringer | 手炮 | 动能 | 12 | 精准击杀引爆萤火 |
| **雷神** Thunderlord | 机枪 | 电弧 | 60 | 每连续 3 次命中召唤雷暴 |
| **旭日** Sunshot | 手炮 | 烈日 | 8 | 每发小爆炸 + 灼烧，换弹后首发 +25% |
| **伊邪那岐的重担** Izanagi's Burden | 狙击枪 | 动能 | 4 | 蓄力 2 秒合成「荣耀之弹」，3.5 倍伤害 |
| **山巅** Mountaintop | 榴弹发射器 | 动能 | 1 | 剧烈爆炸 + 火箭跳 |
| **引力子长矛** Graviton Lance | 脉冲步枪 | 虚空 | 30 | 击杀留下黑洞，吸附并撕咬敌人 |

数值细节（伤害/射速/散布/后坐力）见 [docs/weapons.md](docs/weapons.md)。

---

## 三、怎么用

| 操作 | 效果 |
| --- | --- |
| **右键** | 射击（按住连发） |
| **潜行 + 右键** | 主动换弹 |
| **弹匣打空后右键** | 自动换弹 |
| **按住右键（伊邪那岐）** | 蓄力，松开发射；蓄满 2 秒打出荣耀之弹 |

> 原版对「物品使用」有 4 tick 的客户端冷却，所以自动武器的实际射速上限约为 **5 发/秒**。
> 这不是 bug，所有不改客户端的枪械 mod 都受此限制。

获取方式：创造模式物品栏的**「天命军械库」**页签 / 3×3 合成 / `/give @s destinyarsenal:gjallarhorn`。

---

## 四、和 TaCZ 一起玩

| 项目 | 情况 |
| --- | --- |
| 是否需要 TaCZ | **不需要**。本 mod 零硬依赖，单独也能跑 |
| 能否同装 | **可以**，同为 NeoForge 1.21.1 |
| 物品/命名空间 | TaCZ 用 `tacz:`，本 mod 用 `destinyarsenal:`，无冲突 |
| 物品栏 | 各自一个页签，互不干扰 |
| 按键 | 本 mod **不注册任何按键**（右键/潜行），不会抢占 TaCZ 的 R 换弹、开镜键 |
| 渲染 | 本 mod 无 Mixin，TaCZ 的手持枪械渲染只对 `tacz:` 的枪生效 |
| 弹药/配件 | **不互通**：两边各用各的弹匣逻辑，TaCZ 的配件装不上本 mod 的枪 |
| 特性 | 本 mod 的 8 个特性只对自己的枪生效，不会挂到 TaCZ 的枪上 |

**装法**：把 `tacz-neoforge-1.21.1-*.jar` 和 `destiny2-arsenal-1.1.0.jar` 一起丢进 `mods/`，
前置按 TaCZ 要求装（NeoForge 21.1.x）。进游戏后创造物品栏里会看到两个不同页签。

详细的兼容矩阵、冲突排查、以及「如果想做数据互通该走哪条路」见
[docs/tacz-compat.md](docs/tacz-compat.md)。

### 另外还做了一份 TaCZ 枪包（**已按 1.20.1 / TaCZ 1.1.8 版本化**）

`tacz_pack/d2arsenal_gun_pack/` 是把同样 8 把枪做成 **TaCZ 原生枪包**（纯数据，无需 Java、无需编译）：

- 有 TaCZ 的 **3D 模型渲染、开镜、换弹动画**（模型是方块风占位级，可在 Blockbench 里替换）；
- **复用 TaCZ 的真实弹药**（`45acp` / `762x39` / `338` / `40mm` / `rpg_rocket`）与默认包的
  动画 / 状态机 / 音效 / HUD —— 跨包引用全部核对过；
- 但复杂特性会降级：狼群弹与山巅的爆炸能保留，**亡命叠层、雷暴、蓄力、黑洞在纯数据层做不出来**；
- 装法：整个 zip 丢进实例根目录的 `tacz/`（本机已装到 `逆转未来2.3.3/tacz/`）。

取舍与对照表见 [docs/tacz-pack.md](docs/tacz-pack.md)。**一句话：要特性用 mod，要 3D 和动画用枪包，两个可以同装。**

> ⚠️ 注意版本错位：**Java mod 是 1.21.1 / NeoForge 的**，而枪包是按 **1.20.1 / Forge / TaCZ 1.1.8** 生成的。
> 你那个「逆转未来2.3.3」是 1.20.1 Forge 实例，只能装枪包；要装 Java mod 必须先把工程移植到 Forge 1.20.1
> （加载器不同，NeoForge 的 jar 放进去不会被识别）。

---

## 五、构建

### 依赖版本（已核对为已发布版本）

| 组件 | 版本 |
| --- | --- |
| Minecraft | 1.20.1 |
| Forge | 47.4.0（`[47,)`） |
| ForgeGradle | 6.0.24+ |
| Gradle | 8.10 |
| JDK | **17**（MC 1.20.1 的字节码是 17） |

### 前置：JDK 17

本机原有的是 JDK 25，而 Forge 1.20.1 的开发环境要求 JDK 17。
装 [Temurin 17](https://adoptium.net/)，把 `JAVA_HOME` 指过去（或在 IDE 里指定 Gradle JVM）。

### 构建

```bash
cd destiny2-arsenal
gradle build          # 产物：build/libs/destiny2-arsenal-1.1.0.jar
gradle runClient      # 直接在开发环境启动游戏
gradle selfTest       # 纯 Java 核心自测（不启动游戏）
python tools/validate.py   # 资源/工程一致性校验
```

### 一条命令（Windows）

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1            # 检查 JDK/Gradle → gradle build → 顺带打枪包
powershell -ExecutionPolicy Bypass -File build.ps1 -PackOnly  # 只打 TaCZ 枪包，完全不需要 JDK
```

> 必须带 `-ExecutionPolicy Bypass`：Windows 默认策略禁止运行 `.ps1`。
> 脚本已保存为**带 BOM 的 UTF-8**——否则 Windows PowerShell 5.1 会按 ANSI 解码，中文注释会把脚本撑成语法错误
> （这个坑我在本机踩并修过）。

Linux / macOS 用 `./build.sh`。脚本会先做前置检查（JDK 版本、Gradle 是否存在），
缺什么直接告诉你装哪个，不会抛一堆 Gradle 天书。

### 没有 JDK / 不想本地构建？用 GitHub Actions（推荐）

仓库里附了两份内容相同的工作流：`.github/workflows/build.yml`（git 推送用）和
`ci/build.yml`（**网页拖拽上传时用这份**——GitHub 网页上传会忽略 `.github` 这种点目录）。

**完整点击步骤见 [ci/README.md](ci/README.md)**：建仓库 → 网页上传工程 → 用「Create new file」
新建 `.github/workflows/build.yml` 并粘贴 `ci/build.yml` 的内容 → Actions 里下载 Artifact。
CI 用 JDK 17 + Gradle 8.8 构建，产物是 `destiny2-arsenal-1.2.0.jar`（Java 17 字节码）。

> 你的实例实际跑在 **Forge 47.4.18 + Java 25** 上（从日志确认），
> 而 jar 是 Java 17 字节码，可以在 Java 25 上正常运行；mods.toml 里声明的是 `[47,)`，也覆盖 47.4.18。

### jar 和 jar 不是一回事

| 产物 | 是什么 | 放哪 | 能 `java -jar` 吗 |
| --- | --- | --- | --- |
| `build/libs/destiny2-arsenal-1.1.0.jar` | NeoForge **mod** | `mods/` | 不能（没有 Main-Class） |
| `dist/d2arsenal_gun_pack.jar` | TaCZ **枪包**（本质是 zip） | `tacz/` | 不能（它不是程序） |

两者都叫 jar，但一个是给**加载器**读的模组，一个是给 **TaCZ** 读的数据包。
把枪包丢进 `mods/` 会让 NeoForge 报「no mods.toml」；把 mod 丢进 `tacz/` 则什么都不会发生。

### TaCZ 枪包（不需要 Gradle，不需要 JDK）

```bash
python tools/gen_tacz_pack.py       # 重新生成枪包（74 个文件）
python tools/validate_tacz_pack.py  # 枪包一致性校验（334 项）
python tools/preview_models.py      # 生成模型预览图 docs/tacz-models-preview.png
```

产物在 `tacz_pack/d2arsenal_gun_pack/`，直接丢进实例根目录的 `tacz/` 即可。

> 仓库里带了 `gradle/wrapper/gradle-wrapper.properties`，但**没有** `gradle-wrapper.jar`（二进制不入库）。
> 想用 `./gradlew` 的话，先在有 Gradle 的机器上执行一次 `gradle wrapper --gradle-version 8.10`。

NeoForge 依赖在首次构建时由 ModDevGradle 自动下载，**必须联网**。

### 在开发环境里测 TaCZ 共存

`gradle runClient` 的 `run/` 目录是个独立实例，可以把 TaCZ jar 放进 `run/mods/` 一起启动。
但 TaCZ 自身还有前置要求（见其页面），开发环境里不保证能跑；**验证共存建议用正式实例**。

---

## 六、目录结构

```
destiny2-arsenal/
├── build.gradle / settings.gradle / gradle.properties   ForgeGradle + Forge 47.4.0
├── build.ps1 / build.sh            一键构建脚本（含 JDK/Gradle 前置检查）
├── .github/workflows/build.yml     CI：用 JDK 17 构建 Forge jar 并上传产物
├── dist/                           预打包的 TaCZ 枪包（.zip）
├── src/main/resources/META-INF/mods.toml                模组元数据（含 tacz 可选依赖）
├── src/main/resources/tacz_bundle/ ★ 内嵌的 TaCZ 枪包（首次启动释放到 tacz/）
├── src/main/java/dev/destinyarsenal/
│   ├── DestinyArsenal.java        @Mod 入口（注册物品、物品栏、事件监听）
│   ├── GunHandler.java            开火/换弹/蓄力/tick 推进
│   ├── core/                      ★ 纯 Java，零 Minecraft 依赖，可单元测试
│   │   ├── WeaponCatalog.java     8 把武器的全部数值（改平衡只动这里）
│   │   ├── WeaponDef.java         武器定义 + Builder
│   │   ├── GunRuntime.java        每名玩家的瞬时状态（换弹/层数/蓄力）
│   │   ├── Ballistics.java        伤害衰减、爆头判定、后坐力
│   │   ├── Spread.java            散布角与随机偏移
│   │   ├── PerkEngine.java        特性触发条件与倍率
│   │   ├── Box3.java / Vec3.java  射线-包围盒求交、三维向量
│   │   └── ElementKind / WeaponType
│   ├── combat/                    Minecraft 侧实现（Mojang 官方映射名）
│   │   ├── Hitscan.java           手写 hitscan（方块优先 + 实体最近命中）
│   │   ├── Guns.java              每把枪的特性分支
│   │   ├── Explosions.java        手写范围伤害（不拆地形）
│   │   ├── Scheduler.java         延迟任务（狼群弹/灼烧/黑洞）
│   │   ├── Fx.java                粒子与音效的唯一出口
│   │   └── McVec.java             向量转换
│   ├── item/GunItem.java          物品本身（tooltip / 蓄力 / 弹药条颜色）
│   └── registry/                  DeferredRegister 注册物品与创造页签
├── src/main/resources/            模型 / 贴图 / 语言 / 配方
├── src/test/java/.../CoreSelfTest.java
├── tacz_pack/d2arsenal_gun_pack/  ★ TaCZ 枪包（纯数据：8 枪 + 4 弹药 + 3D 模型）
├── tools/                         贴图/JSON/枪包生成器 + 两套校验脚本
│   ├── gen_textures.py            主 mod 的 16×16 像素贴图
│   ├── gen_json_assets.py         主 mod 的模型/语言/配方
│   ├── gen_tacz_pack.py           TaCZ 枪包生成（几何/数值/语言/配方）
│   ├── preview_models.py          枪包模型的等距投影预览
│   ├── validate.py                主 mod 一致性校验（233 项）
│   ├── validate_tacz_pack.py      枪包校验（415 项，含对真实 TaCZ 默认包的跨包校验）
│   └── tacz_doctor.py             进游戏后体检：读日志判断枪包是否被识别 / 有无报错
└── docs/                          武器表、架构、TaCZ 兼容、枪包说明、验证记录
```

**分层的关键收益**：从 Fabric 移植到 NeoForge 时，`core/` 里 2000 行中的约 700 行**一个字都没改**，
70 条自测直接原样通过。换加载器只需要重写平台层。

---

## 七、两个关键设计选择

### 1. 用「耐久条」当弹药条

Minecraft 1.20.5 之后物品数据改成了 Data Component，`ItemStack#getOrCreateTag` 之类已被移除。
与其自己注册组件类型（多一处容易随版本碎的 API），不如：

```java
new Item.Properties().durability(def.magazine)  // 弹匣容量 = 最大耐久
stack.setDamageValue(stack.getDamageValue() + 1) // 打一发 = 掉一点耐久
stack.setDamageValue(0)                          // 换弹 = 修满
```

好处：**自动持久化、自动同步客户端、自动画弹药条**，还顺带让枪不能堆叠。
代价：枪**不会真的损坏**（代码里从不调用真正的耐久扣血路径，也永远不让 damage 超过弹匣数）。

这也让本 mod 与 TaCZ 的数据体系完全隔离：TaCZ 的枪用 `minecraft:custom_data`，
本 mod 只用原版 `damage` 组件，互不写入。

### 2. 完全不用 Mixin

ADS 缩放、自定义准星、枪械动画都要动原版渲染，都要 Mixin；而 TaCZ 已经大量占用这些注入点。
第一版刻意全部跳过，换取「和 TaCZ 同装也不会打架」的稳定性。
演进路线在 [docs/architecture.md](docs/architecture.md)。

---

## 八、加一把新枪（5 步）

1. `core/WeaponCatalog.java` 里加常量 + `WeaponDef.builder(...)` 块（`perk` 名随便起，如 `"triple_tap"`）；
2. `registry/ModItems.java` 里加一行 `public static final DeferredItem<GunItem> XXX = create(WeaponCatalog.XXX);`；
3. `tools/gen_json_assets.py` 的 `WEAPONS` / `PERKS` / `RECIPES` 补条目并重跑；
4. `tools/gen_textures.py` 加绘制函数（或复用现成的 `gun_hand_cannon` 等）并重跑；
5. 要新机制就在 `combat/Guns.java` 的 `switch (def.perk)` 加一个 `case`。

跑 `python tools/validate.py` + `gradle selfTest` 就知道漏没漏。

---

## 九、编译报错速查

本工程用的是 1.21.1 的 **Mojang 官方映射名**（NeoForge 不用 Yarn）。若某个符号报错，大概率是这几行：

| 报错出现在 | 原因 | 改法 |
| --- | --- | --- |
| `GunItem#appendHoverText` | 1.21.1 签名为 `(ItemStack, Item.TooltipContext, List<Component>, TooltipFlag)` | 已按 1.21.1 写 |
| `InteractionResultHolder` | 1.21.1 仍是它（1.21.2+ 才有变化） | 别改成 `InteractionResult` |
| `Item#getUseDuration` | 1.21.1 是 `(ItemStack, LivingEntity)` | 旧版本只有 `(ItemStack)` |
| `Item#releaseUsing` | 返回 **boolean**（不是 void） | 保留 `return true` |
| `player.setDeltaMovement(x,y,z)` | 老版本只有 `Vec3` 重载 | 换 `new Vec3(...)` |
| `ParticleTypes.SNOWFLAKE` | 1.20.5 新增，仅 `STASIS` 元素用到 | 删掉那个 `case` 即可 |
| `DeferredRegister.Items#registerItem` | 三参重载 `(name, factory, properties)` | 少一个参数也能编 |

---

## 十、已知限制 / 后续规划

- 没有 ADS（右键被射击占用）、没有 3D 枪械模型、没有第一人称动画；
- 没有换弹进度可视化（只在动作栏提示）；
- 没有弹药储备/捡弹系统（换弹不限次数，靠时间成本平衡）；
- 与 TaCZ **不共享弹药/配件**（见 docs/tacz-compat.md 的互通路线）。

想往下做的话，优先级建议：TaCZ 枪包（拿 TaCZ 的模型与动画）→ 弹药互通 → ADS/准星 Mixin。

---

## 十一、许可

MIT。武器名称与设计属于 Bungie《命运 2》，本项目是非官方同人模组，不包含任何游戏原创资源。
