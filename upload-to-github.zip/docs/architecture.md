# 架构说明（NeoForge 1.21.1）

## 分层

```
                  ┌──────────────────────────────────────────┐
   右键 / 松手 ──▶ │  item/GunItem         （物品声明）         │
                  └───────────────┬──────────────────────────┘
                                  ▼
                  ┌──────────────────────────────────────────┐
   ServerTickEvent│  GunHandler           （调度：开火/换弹）   │
      .Post   ───▶│                                        │
                  └───────────────┬──────────────────────────┘
                                  ▼
      ┌──────────────────────────────────────────────────────┐
      │  combat/  Hitscan · Explosions · Guns · Fx · Scheduler│  ← 依赖 MC / NeoForge
      └───────────────┬──────────────────────────────────────┘
                      ▼
      ┌──────────────────────────────────────────────────────┐
      │  core/    WeaponCatalog · Ballistics · Spread ·        │  ← 纯 Java，可自测
      │           PerkEngine · GunRuntime · Box3 · Vec3        │
      └──────────────────────────────────────────────────────┘
```

`core` 包**不 import 任何 `net.minecraft` / `net.neoforged`**：

- 可以用纯 `javac` 编译并跑 70 条断言（`gradle selfTest`）；
- 平衡数值、散布公式、特性触发条件都可以在没有游戏的情况下验证；
- **从 Fabric 移植到 NeoForge 时，`core/` 一个字都没改**，自测原样通过。

这一条由 `tools/validate.py` 的 `check_core_purity()` 持续守着：一旦有人在 `core/` 里
`import net.minecraft...`，校验直接失败。

## 一次开火的完整链路

1. 客户端右键 → 原版发 `ServerboundUseItemPacket`；
2. 服务端 `Player#interact` → `ItemStack#use` → `GunItem#use`；
3. `GunHandler.onUse` 判定：潜行→换弹 / 蓄力→进入使用状态 / 否则→`Guns.fire`；
4. `Guns.fire`：
   - `stack.setDamageValue(damageValue + 1)`（扣弹）；
   - `Spread.effectiveSpread` + `Spread.jitter` 算出这一发的方向；
   - `Hitscan.trace` 求最近命中点（先 `level.clip` 打方块，再自己算射线-包围盒）；
   - `resolve` 结算伤害并按 `def.perk` 触发特性；
   - `Fx` 播放枪口焰/音效，`recoil` 施加极小的竖直冲量。
5. 延迟类效果（狼群弹、灼烧、黑洞）进 `Scheduler`，由 `ServerTickEvent.Post` 统一推进。

## 为什么自己算 hitscan

`ProjectileUtil` 的签名在 1.19 → 1.21 之间变动过，而 `Box3.rayDistance` 是不到 40 行的
slab 算法：没有版本风险、能单测、还能顺手拿到命中点高度做爆头判定。

## 为什么不用 `Level#explode`

1. 原版爆炸会拆方块，枪械 mod 不应该让玩家一炮拆家；
2. 自己算球体内实体 + 距离衰减，能精确控制伤害曲线（见 `Explosions`）；
3. 不依赖爆炸相关的内部枚举（`ExplosionInteraction` 之类跨版本会动）。

## 状态存放策略

| 状态 | 存放位置 | 生命周期 |
| --- | --- | --- |
| 当前弹药 | `ItemStack` 的 `damage` 组件 | 持久化（存盘/跨维度） |
| 换弹进度 | `GunHandler.STATE`（内存 Map） | 掉线/切枪即失效 |
| 亡命层数 / 雷暴计数 | `GunRuntime` | 换弹或切枪清零 |
| 蓄力起始时间 | `GunRuntime` | 松手即清 |

刻意**不持久化**瞬时战斗状态：省去自定义 DataComponent 的版本风险，切枪/掉线重置也符合直觉。
与 TaCZ 的隔离也来自这里：TaCZ 把枪数据放在 `minecraft:custom_data`，本 mod 只碰原版 `damage` 组件。

## 移植记录：Yarn 名 → Mojang 官方名

Fabric 版用的是 Yarn 映射，NeoForge 用 Mojang 官方映射，两边类名/方法名几乎全不一样。
下表是实际改过的对照（也是「想移植回 Fabric」时的反向清单）：

| 概念 | Fabric / Yarn | NeoForge / Mojang |
| --- | --- | --- |
| 入口 | `ModInitializer#onInitialize` | `@Mod` 构造器（注入 `IEventBus`） |
| 注册物品 | `Registry.register(Registries.ITEM, …)` | `DeferredRegister.Items#registerItem` |
| 创造页签 | `FabricItemGroup.builder()` + `ItemGroupEvents` | `DeferredRegister<CreativeModeTab>` + `CreativeModeTab.builder()` |
| 服务端 tick | `ServerTickEvents.END_SERVER_TICK` | `NeoForge.EVENT_BUS` + `ServerTickEvent.Post` |
| 物品使用返回值 | `TypedActionResult<ItemStack>` | `InteractionResultHolder<ItemStack>` |
| 使用时长 | `getMaxUseTime(stack, user)` | `getUseDuration(stack, entity)` |
| 使用动画 | `getUseAction` / `UseAction` | `getUseAnimation` / `UseAnim` |
| 松手回调 | `onStoppedUsing(...)`（void） | `releaseUsing(...)`（**boolean**） |
| 提示文本 | `appendTooltip(…, TooltipType)` / `Text` | `appendHoverText(…, TooltipFlag)` / `Component` |
| 耐久条颜色 | `getItemBarColor` | `getBarColor` |
| 弹药计数 | `stack.getDamage()/setDamage()` | `stack.getDamageValue()/setDamageValue()` |
| 造成伤害 | `entity.damage(src, amount)` | `entity.hurt(src, amount)` |
| 伤害源 | `world.getDamageSources()` | `level.damageSources()` |
| 视线/视向量 | `getEyePos()` / `getRotationVec()` | `getEyePosition()` / `getViewVector()` |
| 方块射线 | `world.raycast(RaycastContext)` | `level.clip(ClipContext)` |
| 附近实体 | `world.getOtherEntities(except, box, pred)` | `level.getEntities(except, aabb, pred)` |
| 包围盒 | `Box` | `AABB` |
| 粒子 | `ServerWorld#spawnParticles` / `ParticleEffect` | `ServerLevel#sendParticles` / `ParticleOptions` |
| 音效类别 | `SoundCategory` | `SoundSource` |
| 颜色格式 | `Formatting` | `ChatFormatting` |
| 向量 | `Vec3d`（`lengthSquared()`） | `Vec3`（`lengthSqr()`） |
| 潜行 | `isSneaking()` | `isShiftKeyDown()` |
| 速度 | `setVelocity()` / `velocityModified` | `setDeltaMovement()` / `hasImpulse` |
| 动作栏消息 | `sendMessage(text, true)` | `displayClientMessage(component, true)` |
| 客户端判断 | `world.isClient` | `level.isClientSide` |

## 演进路线

| 阶段 | 内容 | 需要的额外手段 |
| --- | --- | --- |
| 0（当前） | 弹匣/换弹/特性/粒子/音效，NeoForge 1.21.1 | 无（只用注册表 + 事件总线） |
| 1 | 弹药储备 + 捡弹 + HUD 弹药数 | `RegisterGuiLayersEvent`（NeoForge） |
| 2 | ADS 缩放与准星 | Mixin —— **与 TaCZ 的注入点可能重叠，需要逐版本验证** |
| 3 | 3D 枪械模型 + 第一人称动画 | `IClientItemExtensions` / `ItemStackRenderers` |
| 4 | 与 TaCZ 数据互通 | 见 `docs/tacz-compat.md` 第四节（路线 A/B/C） |

> 阶段 2 起就会和 TaCZ 抢同一个渲染入口，这也是第一版刻意不做 Mixin 的原因。
