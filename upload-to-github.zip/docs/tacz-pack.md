# TaCZ 枪包（1.20.1 / TaCZ 1.1.8）

> 目标环境：**Minecraft 1.20.1 + Forge + TaCZ 1.1.8-hotfix**
> 与你实例里的 `tacz/tacz_default_gun` 逐字段对照生成，跨包引用全部核对过。
> 已安装到：`E:\mc\libs\.minecraft\versions\逆转未来2.3.3\tacz\d2arsenal_gun_pack.zip`

![模型预览](tacz-models-preview.png)

---

## 一、和之前 1.21.1 版的区别（重要）

| 项目 | 旧版（1.21.1 / TaCZ 1.2.0） | 现在（1.20.1 / TaCZ 1.1.8） |
| --- | --- | --- |
| 配方目录 | `data/<ns>/recipe/`（单数）+ 原版合成 | `data/<ns>/recipes/gun/`（复数）+ `tacz:gun_smith_table_crafting` |
| 弹药 | 自带 4 种自定义弹药 | **复用 TaCZ 真实弹药**：`45acp` / `762x39` / `338` / `40mm` / `rpg_rocket` |
| 动画 | 只写 `third_person_animation: default` | **跨包借用**默认包的 `animation` + `state_machine` |
| 音效 | 无 | **跨包借用**默认包 `.ogg`（shoot / draw / put_away / silence 等） |
| 数据字段 | 1.2.0 精简版 | 1.1.8 完整版（`weight`/`movement_speed`/`melee`/`extra_damage`/`fire_sound`…） |
| 文件数 | 74 | 60（不再带弹药，多了数据字段） |

**复用 TaCZ 弹药 = 真正的数据互通**：玩家用 TaCZ 的弹药箱/弹药物品给这 8 把枪供弹，不需要额外物品。

## 二、包里有什么

```
tacz_pack/d2arsenal_gun_pack/
├── gunpack.meta.json                     namespace = d2arsenal，依赖 tacz >= 1.1.4
├── assets/d2arsenal/
│   ├── gunpack_info.json                 枪包信息
│   ├── lang/en_us.json, zh_cn.json       枪名 + tooltip（特性描述）
│   ├── geo_models/gun/*_geo.json         8 个基岩版模型（含全部定位组）
│   ├── textures/gun/uv/*.png             64×64 调色板图集
│   ├── textures/gun/slot/*.png           32×32 背包图标
│   └── display/guns/*_display.json       模型/贴图/动画/状态机/音效/HUD 引用
└── data/d2arsenal/
    ├── index/guns/*.json                 枪械定义（type / tooltip / sort）
    ├── data/guns/*_data.json             完整 1.1.8 数值
    └── recipes/gun/*.json                枪械工作台配方
```

## 三、每把枪借用了哪套动作

跨枪包引用用 `<stem>` 同时解析到 `animations/<stem>.animation.json` 与
`scripts/<stem>_state_machine.lua`（两者必须都存在，已逐个核对）：

| 武器 | TaCZ 真弹药 | 借用动作来自 | 说明 |
| --- | --- | --- | --- |
| 狼嚎 | `tacz:rpg_rocket` | `m870` | 单发 + 泵动换弹，最接近 1 发火箭 |
| 山巅 | `tacz:40mm` | `m870` | 榴弹发射器口径直接对上 |
| 最后的话语 / 命运终结者 / 旭日 | `tacz:45acp` | `timeless50` | 大口径手枪 |
| 雷神 | `tacz:762x39` | `m249` | 机枪弹链 |
| 引力子长矛 | `tacz:762x39` | `ak47` | 步枪 |
| 伊邪那岐的重担 | `tacz:338` | `m107` | 大口径狙击 |

> 代价：动作是**借来的**，所以狼嚎会做出「泵动霰弹枪」的换弹动作。
> 要变成本命动作，得用 Blockbench + TaCZ 动画导出做一套（见第七节）。

## 四、特性映射（数据层能表达多少）

TaCZ 1.1.8 的数据层比 1.2.0 更丰富，这次能多保留一些：

| 原特性 | 在枪包里怎么实现 | 保留 |
| --- | --- | --- |
| 狼嚎 · 狼群弹 | `bullet.explosion{radius:4, damage}` 单次爆炸 | ⚠️ 部分（无 6 枚子母弹） |
| 山巅 · 微型导弹 | `bullet.explosion{radius:5}` + 大后坐力 | ✅ 基本完整 |
| 旭日 · 日爆 | `bullet.ignite{entity:true}` + 爆炸 | ⚠️ 部分 |
| 命运终结者 · 萤火 | 无「精准击杀才爆」的条件判定 | ❌ |
| 最后的话语 · 亡命叠层 | 无叠层机制 | ❌ |
| 雷神 · 雷暴 | 无三连击触发 | ❌ |
| 伊邪那岐 · 蓄力合弹 | 1.1.8 schema 里有 `charging` 字段，但需要配套 Lua 状态机，**未启用** | ❌ |
| 引力子长矛 · 黑洞 | 需要 Lua + 实体逻辑 | ❌ |

**要完整特性 → 用 NeoForge 版 Java mod；要 3D 模型/开镜/换弹动画 → 用这个枪包。**

## 五、装法与验证

已装好：`tacz/d2arsenal_gun_pack.zip`（和你在用的其它枪包一样是 zip 形态）。

### 进游戏后的自查（一次命令）

```bash
python tools/tacz_doctor.py                     # 默认读 逆转未来2.3.3 实例
python tools/tacz_doctor.py --instance "E:/你的实例"
```

它会做三件事：读 `tacz/` 里所有 zip 的命名空间与枪数、读 `logs/latest.log` 里 TaCZ 的枪包扫描记录、
筛出与枪包相关的报错，最后给结论（退出码 0 = 正常）。

**成功的判据**（TaCZ 启动时会打印，脚本也会抓）：

```
- d2arsenal_gun_pack.zip, Main namespace: d2arsenal
Found 6 possible gunpack(s) and added them to resource set.     ← 现在是 5，加了本包应该是 6
```

### 当前静态检查结果（安装后、未启动游戏）

- 命名空间 `d2arsenal` 与现有的 `tacz / zeta / eos / emitech / sfms` **不冲突**；
- 另外 4 个社区包共 148 把枪，与我这 8 个 id（`gjallarhorn` 等）**没有一个重名**；
- 安装的 zip 与构建产物 **sha256 一致**；
- 日志里暂无 `d2arsenal` 记录 → 需要重启一次游戏（这条是预期内的）。

- 进游戏后创造模式物品栏 / 枪械工作台里会出现 **Destiny 2 Arsenal** 枪包与 8 把枪；
- 热重载：`/tacz reload`；
- 想卸载：删掉那个 zip 即可（不影响其它枪包）；
- 别用文件夹 + zip 同时装同一个 `d2arsenal` 命名空间，会互相覆盖。

`python tools/validate_tacz_pack.py` 做了 **415 项**检查，全部通过，其中**跨包引用是真校验**：

- `animation` / `state_machine` 指向的 `.animation.json`、`_state_machine.lua` 在默认包里真实存在；
- `sounds` 里每个音效（`tacz:<stem>/<stem>_shoot` 等）都对应到真实 `.ogg` 文件；
- `hud` / `muzzle_flash` 贴图真实存在；
- `ammo` 用的是默认包里真实存在的弹药 id；
- data / display / index / recipe 的顶层字段不得超出 1.1.8 的真实 schema（防拼写错误）；
- geo 模型含 `root` / `magazine` / `mag_standard` / `lefthand_pos` / `righthand_pos` /
  `idle_view` / `iron_view` / `ground` / `thirdperson_hand` / `fixed`，手臂预览方块为 4×12×4；
- 贴图尺寸（uv 64×64、slot 32×32）。

**仍未验证**：进游戏实际加载。第一次请重点看：枪是否出现在枪包列表、能否开火、换弹动作是否错位、
模型朝向是否需要在 Blockbench 里微调。

## 六、已知限制

- 动作/音效/动画全部**依赖 TaCZ 默认包**（`tacz/tacz_default_gun`）。若把默认包删了，这些引用会失效；
- 模型定位组是按几何锚点算的，手的贴合位置与机瞄视角建议在 Blockbench（FOV 70）里复核；
- 配件槽已关闭（`allow_attachment_types: []`），因为模型里还没有 `muzzle_pos` / `scope_pos` 等配件定位组；
- 每把枪的 2D HUD 图借用了默认包对应枪的（手炮没有 HUD 图，按官方文档留空=不渲染）。

## 七、想继续提升的路线

1. **正经动画**：用 Blockbench + TaCZ 动画导出，做出 `*_animation.json` + `*_state_machine.lua`，
   把 `display.animation/state_machine` 从 `tacz:xxx` 改成自己的 `d2arsenal:xxx`；
2. **配件槽**：在模型里补 `muzzle_pos` / `scope_pos` / `stock_pos` / `grip_pos` / `laser_pos`，
   再把 `allow_attachment_types` 打开；
3. **完整特性**：写 Lua 状态机（1.1.8 支持 Lua 脚本，默认包里 `*_state_machine.lua` 就是范例）；
4. **独立 HUD / 独立音效**：把 `hud`、`sounds` 指向自己包内的资源。
