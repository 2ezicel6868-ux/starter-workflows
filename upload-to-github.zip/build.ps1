﻿# 把《命运 2》军械库编译成 .jar
#
# 前提：JDK 21 + Gradle（≥ 8.8）+ 首次构建时能联网（拉 Minecraft / NeoForge 依赖）
# 用法：pwsh -File build.ps1
#       pwsh -File build.ps1 -PackOnly   # 只打 TaCZ 枪包，不需要 JDK

param(
    [switch]$PackOnly
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Fail($message) {
    Write-Host ""
    Write-Host "[失败] $message" -ForegroundColor Red
    exit 1
}

function Get-PythonCommand {
    foreach ($candidate in @("python", "python3", "py")) {
        $cmd = Get-Command $candidate -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    }
    return $null
}

# ---------------------------------------------------------------- 只打枪包
if ($PackOnly) {
    $pythonCmd = Get-PythonCommand
    if (-not $pythonCmd) {
        Fail "打包枪包需要 Python 3。或者手动把 tacz_pack\d2arsenal_gun_pack 整个文件夹压成 zip。"
    }
    & $pythonCmd tools/package_pack.py
    exit $LASTEXITCODE
}

# ---------------------------------------------------------------- 检查 JDK
$java = Get-Command java -ErrorAction SilentlyContinue
if (-not $java) {
    Fail "没有找到 java。请安装 JDK 21（https://adoptium.net/），并把 JAVA_HOME / PATH 指过去。"
}

$versionText = (& java -version 2>&1 | Out-String)
$match = [regex]::Match($versionText, 'version "(\d+)')
if (-not $match.Success) {
    Fail "无法识别 java 版本：`n$versionText"
}
$major = [int]$match.Groups[1].Value
Write-Host "JDK 主版本：$major"
if ($major -lt 21) {
    Fail "Forge 1.20.1 / Minecraft 1.20.1 需要 JDK 17 或更高，当前是 $major。"
}
if ($major -ne 21) {
    Write-Host "[警告] 当前不是 JDK 21（是 $major）。Gradle 8.10 跑不了 Java 25，" -ForegroundColor Yellow
    Write-Host "        建议把 JAVA_HOME 指向 JDK 17 再构建，否则可能在映射/编译阶段报错。" -ForegroundColor Yellow
    Write-Host "        'Unsupported class file major version'。" -ForegroundColor Yellow
}

# ---------------------------------------------------------------- 检查 Gradle
$gradle = Get-Command gradle -ErrorAction SilentlyContinue
if ($gradle) {
    $gradleCmd = "gradle"
} elseif (Test-Path ".\gradlew.bat") {
    $gradleCmd = ".\gradlew.bat"
} elseif (Test-Path ".\gradlew") {
    $gradleCmd = ".\gradlew"
} else {
    Fail @"
没有找到 Gradle。三种解法任选其一：
  1) 安装 Gradle 8.10：https://gradle.org/install/（或 scoop install gradle）
  2) 生成 wrapper：在有 Gradle 的机器上执行 gradle wrapper --gradle-version 8.10
  3) 用 GitHub Actions：把仓库推到 GitHub，走 .github/workflows/build.yml
"@
}

# ---------------------------------------------------------------- 构建
Write-Host ""
Write-Host "开始构建（首次会下载 Minecraft / NeoForge 依赖，需要几分钟）..." -ForegroundColor Cyan
& $gradleCmd build --no-daemon
if ($LASTEXITCODE -ne 0) {
    Fail "gradle build 失败，请把上面的报错发我。"
}

$jars = Get-ChildItem "build\libs\*.jar" -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notlike "*-sources*" -and $_.Name -notlike "*-dev*" }
if (-not $jars) {
    Fail "构建完成但 build\libs 下没有找到 mod jar。"
}

Write-Host ""
Write-Host "mod jar：" -ForegroundColor Green
$jars | ForEach-Object { Write-Host "  $($_.FullName)  ($([math]::Round($_.Length / 1MB, 2)) MB)" }

# ---------------------------------------------------------------- 顺带打枪包
$pythonCmd = Get-PythonCommand
if ($pythonCmd) {
    Write-Host ""
    Write-Host "顺便生成 TaCZ 枪包..." -ForegroundColor Cyan
    & $pythonCmd tools/package_pack.py
} else {
    Write-Host ""
    Write-Host "[提示] 没找到 Python，跳过枪包打包（不影响 mod jar）。" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "完成。把 mod jar 放进 mods/；枪包（dist\*.jar 或 *.zip）放进 tacz/。" -ForegroundColor Green
