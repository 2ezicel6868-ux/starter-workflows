package dev.destinyarsenal.core;

import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * 纯 Java 自测（不依赖 Minecraft / JUnit）。
 * <p>运行：{@code ./gradlew selfTest}，或直接：
 * {@code javac -d out $(find src/main/java/dev/destinyarsenal/core src/test -name '*.java') && java -cp out dev.destinyarsenal.core.CoreSelfTest}</p>
 */
public final class CoreSelfTest {

    private static int passed = 0;
    private static int failed = 0;

    private CoreSelfTest() {
    }

    public static void main(String[] args) {
        testCatalog();
        testBoxRaycast();
        testSpread();
        testBallistics();
        testPerks();
        testRuntime();

        System.out.println();
        System.out.println("=====================================");
        System.out.println("通过: " + passed + " / " + (passed + failed));
        if (failed > 0) {
            System.out.println("失败: " + failed);
            System.exit(1);
        }
        System.out.println("全部通过 ✔");
    }

    // ------------------------------------------------------------ 断言

    private static void check(String name, boolean condition) {
        if (condition) {
            passed++;
            System.out.println("  [ok]   " + name);
        } else {
            failed++;
            System.out.println("  [FAIL] " + name);
        }
    }

    private static void checkNear(String name, double actual, double expected, double tolerance) {
        boolean ok = Math.abs(actual - expected) <= tolerance;
        if (!ok) {
            System.out.println("        期望 " + expected + "，实际 " + actual);
        }
        check(name, ok);
    }

    private static void section(String title) {
        System.out.println();
        System.out.println(title);
    }

    // ------------------------------------------------------------ 用例

    private static void testCatalog() {
        section("[武器表]");
        check("共 8 把武器", WeaponCatalog.ALL.size() == 8);

        Set<String> ids = new HashSet<>();
        boolean uniqueIds = true;
        boolean saneNumbers = true;
        boolean chargeOnlyOnIzanagi = true;

        for (WeaponDef def : WeaponCatalog.ALL) {
            uniqueIds &= ids.add(def.id);
            saneNumbers &= def.magazine >= 1
                    && def.reloadTicks > 0
                    && def.fireIntervalTicks >= 1
                    && def.damage > 0.0F
                    && def.range > 0.0F
                    && def.hipSpread >= def.bracedSpread
                    && def.critMultiplier >= 1.0F;
            if (def.chargeable) {
                chargeOnlyOnIzanagi &= WeaponCatalog.IZANAGI.equals(def.id);
                chargeOnlyOnIzanagi &= def.empoweredCost > 0 && def.empoweredCost < def.magazine;
                chargeOnlyOnIzanagi &= def.empoweredMultiplier > 1.0F;
            }
        }

        check("id 唯一", uniqueIds);
        check("数值全部合法（弹匣/换弹/射速/伤害/射程/散布）", saneNumbers);
        check("蓄力机制只挂在伊邪那岐且消耗 < 弹匣", chargeOnlyOnIzanagi);

        WeaponDef lastWord = WeaponCatalog.get(WeaponCatalog.LAST_WORD);
        check("最后的话语：腰射散布 > 精准散布", lastWord.hipSpread > lastWord.bracedSpread);
        check("最后的话语：射速高于命运终结者",
                lastWord.fireIntervalTicks < WeaponCatalog.get(WeaponCatalog.FATEBRINGER).fireIntervalTicks);
        check("狼嚎弹匣为 1（发射器）", WeaponCatalog.get(WeaponCatalog.GJALLARHORN).magazine == 1);
        check("雷神弹匣最大", WeaponCatalog.get(WeaponCatalog.THUNDERLORD).magazine == 60);
        check("roundsLeft 计算正确", lastWord.roundsLeft(3) == 5 && lastWord.roundsLeft(8) == 0);
    }

    private static void testBoxRaycast() {
        section("[射线 / 包围盒]");
        Box3 box = Box3.of(new Vec3(0.0D, 0.0D, 0.0D), 1.0D);

        double front = box.rayDistance(new Vec3(-5.0D, 0.0D, 0.0D), new Vec3(1.0D, 0.0D, 0.0D));
        checkNear("正面命中距离 = 4", front, 4.0D, 1.0E-9D);

        double miss = box.rayDistance(new Vec3(-5.0D, 5.0D, 0.0D), new Vec3(1.0D, 0.0D, 0.0D));
        check("侧上方射线打空", miss == Double.MAX_VALUE);

        double parallelOutside = box.rayDistance(new Vec3(0.0D, 5.0D, 0.0D), new Vec3(0.0D, 0.0D, 1.0D));
        check("平行且在盒外的射线打空", parallelOutside == Double.MAX_VALUE);

        double parallelInside = box.rayDistance(new Vec3(0.0D, 0.0D, -5.0D), new Vec3(0.0D, 0.0D, 1.0D));
        checkNear("平行且穿过盒子的射线命中", parallelInside, 4.0D, 1.0E-9D);

        Box3 stretched = Box3.of(new Vec3(0.0D, 0.0D, 0.0D), 1.0D).stretch(new Vec3(9.0D, 0.0D, 0.0D));
        check("stretch 会把点纳入盒子", stretched.max().x() == 9.0D);
        check("expand 会同时扩展两端", stretched.expand(1.0D).min().x() == -2.0D);
    }

    private static void testSpread() {
        section("[散布]");
        WeaponDef sniper = WeaponCatalog.get(WeaponCatalog.IZANAGI);
        double still = Spread.effectiveSpread(sniper, false, false, false);
        double braced = Spread.effectiveSpread(sniper, false, false, true);
        double sprinting = Spread.effectiveSpread(sniper, true, false, false);
        double airborne = Spread.effectiveSpread(sniper, false, true, false);

        check("潜行最准", braced < still);
        check("冲刺最散", sprinting > still);
        check("滞空比静止更散", airborne > still);
        check("冲刺比滞空更散", sprinting > airborne);

        Vec3 look = new Vec3(0.0D, 0.0D, 1.0D);
        Vec3 perfect = Spread.jitter(look, 0.0D, new Random(42L));
        check("零散布时方向不变", perfect.subtract(look).length() < 1.0E-9D);

        Vec3 jittered = Spread.jitter(look, 5.0D, new Random(42L));
        double cos = jittered.normalize().dot(look);
        double limit = Math.cos(Math.toRadians(5.0D));
        check("偏移角不超过设定散布", cos >= limit - 1.0E-9D);
        check("偏移后仍是单位向量", Math.abs(jittered.length() - 1.0D) < 1.0E-9D);

        Vec3 again = Spread.jitter(look, 5.0D, new Random(42L));
        check("同种子可复现", again.subtract(jittered).length() < 1.0E-12D);
    }

    private static void testBallistics() {
        section("[弹道学]");
        checkNear("射程内满伤", Ballistics.damageAtDistance(10.0F, 10.0D, 30.0D), 10.0D, 1.0E-6D);

        float beyond = Ballistics.damageAtDistance(10.0F, 45.0D, 30.0D);
        check("超出射程伤害下降", beyond < 10.0F);
        check("超出射程伤害不低于下限", beyond >= 10.0F * Ballistics.MIN_FALLOFF - 1.0E-6F);

        check("头部算精准命中", Ballistics.isCriticalHit(1.6D, 0.0D, 1.8D));
        check("脚部不算精准命中", !Ballistics.isCriticalHit(0.2D, 0.0D, 1.8D));
        check("零高度不算精准命中", !Ballistics.isCriticalHit(1.0D, 0.0D, 0.0D));

        checkNear("爆心伤害为满伤", Ballistics.explosionDamage(10.0F, 0.0D, 4.0D), 10.0D, 1.0E-6D);
        check("边缘伤害递减", Ballistics.explosionDamage(10.0F, 3.5D, 4.0D) < 10.0F);
        check("边缘伤害非负", Ballistics.explosionDamage(10.0F, 4.0D, 4.0D) > 0.0F);

        Vec3 center = new Vec3(0.0D, 0.0D, 0.0D);
        Vec3 ring = Ballistics.ringOffset(center, 2.0D, 0, 6);
        checkNear("环形偏移半径正确", Math.sqrt(ring.x() * ring.x() + ring.z() * ring.z()), 2.0D, 1.0E-9D);

        Vec3 kick = Ballistics.recoilImpulse(WeaponCatalog.get(WeaponCatalog.GJALLARHORN), false);
        Vec3 airKick = Ballistics.recoilImpulse(WeaponCatalog.get(WeaponCatalog.GJALLARHORN), true);
        check("后坐力向上且滞空时更小", kick.y() > 0.0D && airKick.y() < kick.y());
    }

    private static void testPerks() {
        section("[特性逻辑]");
        checkNear("亡命 0 层无加成", PerkEngine.damageMultiplier("desperado", 0), 1.0D, 1.0E-6D);
        checkNear("亡命 3 层 +18%", PerkEngine.damageMultiplier("desperado", 3), 1.18D, 1.0E-6D);
        checkNear("亡命 5 层 +30%", PerkEngine.damageMultiplier("desperado", 5), 1.30D, 1.0E-6D);
        checkNear("亡命溢出封顶", PerkEngine.damageMultiplier("desperado", 99), 1.30D, 1.0E-6D);
        checkNear("其他特性无加成", PerkEngine.damageMultiplier("firefly", 5), 1.0D, 1.0E-6D);

        check("只有亡命会叠层", PerkEngine.stacksOnHit("desperado") && !PerkEngine.stacksOnHit("firefly"));
        check("雷神第 3 次命中触发", PerkEngine.shouldTriggerThunder("lightning_rounds", 3));
        check("雷神第 2 次不触发", !PerkEngine.shouldTriggerThunder("lightning_rounds", 2));
        check("其他武器不会触发雷暴", !PerkEngine.shouldTriggerThunder("firefly", 9));

        check("萤火需要精准 + 击杀", PerkEngine.triggersFirefly("firefly", true, true));
        check("萤火非精准不触发", !PerkEngine.triggersFirefly("firefly", false, true));
        check("萤火未击杀不触发", !PerkEngine.triggersFirefly("firefly", true, false));
        check("奇点只需击杀", PerkEngine.triggersSingularity("black_hole", true));
        check("旭日每发都爆", PerkEngine.hasImpactBlast("sunblast"));

        WeaponDef izanagi = WeaponCatalog.get(WeaponCatalog.IZANAGI);
        checkNear("伊邪那岐蓄力伤害 = 3.5x",
                PerkEngine.empoweredDamage(izanagi, true), izanagi.damage * 3.5D, 1.0E-4D);
        checkNear("伊邪那岐普通射击 = 1x",
                PerkEngine.empoweredDamage(izanagi, false), izanagi.damage, 1.0E-4D);
    }

    private static void testRuntime() {
        section("[换弹 / 射击状态机]");
        WeaponDef def = WeaponCatalog.get(WeaponCatalog.FATEBRINGER);
        GunRuntime runtime = new GunRuntime();
        runtime.select(def.id);

        check("初始可以开枪", runtime.canShoot(0L, def.fireIntervalTicks));
        runtime.markShot(100L);
        check("刚开完枪不能立刻再开", !runtime.canShoot(101L, def.fireIntervalTicks));
        check("冷却结束后可以再开", runtime.canShoot(100L + def.fireIntervalTicks, def.fireIntervalTicks));

        check("开始换弹", runtime.startReload(200L, def.reloadTicks));
        check("换弹中不能开枪", !runtime.canShoot(210L, def.fireIntervalTicks));
        check("换弹中不能重复开始", !runtime.startReload(210L, def.reloadTicks));
        check("换弹完成前 isReloading 为真", runtime.isReloading(210L));
        check("未到时间不完成换弹", !runtime.finishReload(210L));
        check("到时间完成换弹", runtime.finishReload(200L + def.reloadTicks));
        check("换弹后进入强化一发状态", runtime.isPrimed());
        check("换弹后不再处于换弹中", !runtime.isReloading());

        runtime.markShot(300L);
        check("开火会消耗强化状态", !runtime.isPrimed());

        runtime.addStack(PerkEngine.DESPERADO_MAX_STACKS);
        runtime.addStack(PerkEngine.DESPERADO_MAX_STACKS);
        check("叠层生效", runtime.stacks() == 2);
        for (int i = 0; i < 10; i++) {
            runtime.addStack(PerkEngine.DESPERADO_MAX_STACKS);
        }
        check("叠层封顶 5", runtime.stacks() == PerkEngine.DESPERADO_MAX_STACKS);

        runtime.startReload(400L, def.reloadTicks);
        float progress = runtime.reloadProgress(400L + def.reloadTicks / 2);
        check("换弹进度在 0..1 之间", progress > 0.0F && progress < 1.0F);
        runtime.finishReload(400L + def.reloadTicks);
        check("换弹清空层数", runtime.stacks() == 0);

        // 换枪：清理与武器绑定的状态，但不影响开火冷却
        long before = runtime.lastShotTick();
        runtime.cancelReload();
        runtime.select(WeaponCatalog.GJALLARHORN);
        check("换枪清空层数", runtime.stacks() == 0);
        check("换枪不影响上一枪时间戳", runtime.lastShotTick() == before);

        runtime.beginCharge(500L);
        check("蓄力计时正确", runtime.chargeTicks(520L) == 20);
        runtime.endCharge();
        check("结束蓄力后计时归零", runtime.chargeTicks(520L) == 0);
    }
}
