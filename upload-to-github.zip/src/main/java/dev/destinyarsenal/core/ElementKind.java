package dev.destinyarsenal.core;

/**
 * 伤害元素。颜色用于物品耐久条与粒子，{@code key} 用于语言文件与音效挑选。
 */
public enum ElementKind {
    KINETIC("kinetic", 0xD8DEE6),
    SOLAR("solar", 0xFF7A2F),
    ARC("arc", 0x6FD3FF),
    VOID("void", 0xB269FF),
    STASIS("stasis", 0x8FD8FF);

    private final String key;
    private final int color;

    ElementKind(String key, int color) {
        this.key = key;
        this.color = color;
    }

    public String key() {
        return this.key;
    }

    /** 0xRRGGBB。 */
    public int color() {
        return this.color;
    }

    public String translationKey() {
        return "weapon.destinyarsenal.element." + this.key;
    }
}
