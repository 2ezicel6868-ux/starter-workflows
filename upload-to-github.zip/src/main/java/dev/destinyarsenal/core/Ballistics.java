package dev.destinyarsenal.core;

/**
 * 伤害衰减、精准判定、后坐力冲量等弹道学计算（纯 Java）。
 */
public final class Ballistics {

    /** 高于实体这个身高比例算「精准命中」（爆头）。 */
    public static final double CRIT_HEIGHT_RATIO = 0.72D;
    /** 超出射程后的最小伤害系数，避免远距离完全打不动。 */
    public static final float MIN_FALLOFF = 0.35F;

    private Ballistics() {
    }

    /**
     * 距离衰减：射程内满伤，超出后线性下降到 {@link #MIN_FALLOFF}。
     */
    public static float damageAtDistance(float baseDamage, double distance, double range) {
        if (range <= 0.0D || distance <= range) {
            return baseDamage;
        }
        double overflow = (distance - range) / range;
        float factor = (float) Math.max(MIN_FALLOFF, 1.0D - overflow * 0.65D);
        return baseDamage * factor;
    }

    /** 命中点是否算精准命中。 */
    public static boolean isCriticalHit(double hitY, double entityY, double entityHeight) {
        if (entityHeight <= 0.0D) {
            return false;
        }
        double relative = (hitY - entityY) / entityHeight;
        return relative >= CRIT_HEIGHT_RATIO;
    }

    /**
     * 后坐力：把准星往「上 + 后」推一点。
     * <p>MC 里没有可写的俯仰角，所以用很小的位移冲量来模拟踢枪，
     * 数值刻意做得很小，不会真的影响走位。</p>
     */
    public static Vec3 recoilImpulse(WeaponDef def, boolean airborne) {
        double strength = def.recoil * def.type.handling();
        if (airborne) {
            strength *= 0.5D;
        }
        return new Vec3(0.0D, strength * 0.55D, 0.0D);
    }

    /** 爆炸伤害随距离衰减。 */
    public static float explosionDamage(float baseDamage, double distance, double radius) {
        if (radius <= 0.0D) {
            return baseDamage;
        }
        double t = Math.min(1.0D, Math.max(0.0D, distance / radius));
        return baseDamage * (float) (1.0D - 0.55D * t);
    }

    /** 环形散布的落点（用于狼群弹、奇点等特效的位置）。 */
    public static Vec3 ringOffset(Vec3 center, double radius, int index, int total) {
        double angle = (Math.PI * 2.0D) * index / Math.max(1, total);
        return center.add(Math.cos(angle) * radius, 0.15D, Math.sin(angle) * radius);
    }
}
