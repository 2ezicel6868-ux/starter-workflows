package dev.destinyarsenal.core;

/**
 * 轴对齐包围盒 + 射线求交（纯 Java，可单元测试）。
 * <p>用于手写弹道命中判定：先算射线与实体包围盒的最近交点，再决定打中谁。
 * 这样不依赖 {@code ProjectileUtil} 之类容易随版本变动的 API。</p>
 */
public record Box3(Vec3 min, Vec3 max) {

    public static Box3 of(Vec3 center, double radius) {
        return new Box3(
                center.add(-radius, -radius, -radius),
                center.add(radius, radius, radius));
    }

    /** 从两个角点构造（顺序无所谓）。 */
    public static Box3 between(Vec3 a, Vec3 b) {
        return new Box3(
                new Vec3(Math.min(a.x(), b.x()), Math.min(a.y(), b.y()), Math.min(a.z(), b.z())),
                new Vec3(Math.max(a.x(), b.x()), Math.max(a.y(), b.y()), Math.max(a.z(), b.z())));
    }

    public Box3 expand(double amount) {
        return new Box3(
                min.subtract(amount, amount, amount),
                max.add(amount, amount, amount));
    }

    /** 等价于 Minecraft 的 {@code AABB.stretch(Vec3d)}：把一个点纳入盒子。 */
    public Box3 stretch(Vec3 point) {
        return new Box3(
                new Vec3(Math.min(min.x(), point.x()), Math.min(min.y(), point.y()), Math.min(min.z(), point.z())),
                new Vec3(Math.max(max.x(), point.x()), Math.max(max.y(), point.y()), Math.max(max.z(), point.z())));
    }

    public Vec3 center() {
        return min.lerp(max, 0.5D);
    }

    /**
     * 射线与该盒子求交（slab 算法）。
     *
     * @param origin 射线起点
     * @param direction 已归一化的方向向量
     * @return 最近交点的距离；无交点返回 {@link Double#MAX_VALUE}
     */
    public double rayDistance(Vec3 origin, Vec3 direction) {
        double tMin = 0.0D;
        double tMax = Double.MAX_VALUE;

        double[] o = {origin.x(), origin.y(), origin.z()};
        double[] d = {direction.x(), direction.y(), direction.z()};
        double[] lo = {min.x(), min.y(), min.z()};
        double[] hi = {max.x(), max.y(), max.z()};

        for (int axis = 0; axis < 3; axis++) {
            if (Math.abs(d[axis]) < 1.0E-8D) {
                // 射线平行于该轴：起点必须落在 slab 内
                if (o[axis] < lo[axis] || o[axis] > hi[axis]) {
                    return Double.MAX_VALUE;
                }
                continue;
            }
            double inv = 1.0D / d[axis];
            double t1 = (lo[axis] - o[axis]) * inv;
            double t2 = (hi[axis] - o[axis]) * inv;
            if (t1 > t2) {
                double tmp = t1;
                t1 = t2;
                t2 = tmp;
            }
            tMin = Math.max(tMin, t1);
            tMax = Math.min(tMax, t2);
            if (tMin > tMax) {
                return Double.MAX_VALUE;
            }
        }
        return tMin;
    }
}
