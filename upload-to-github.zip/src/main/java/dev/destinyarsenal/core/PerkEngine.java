package dev.destinyarsenal.core;

/**
 * 特性（perk）的纯逻辑：层数上限、倍率、触发条件。
 * <p>把「什么时候该爆发」这类判断从 Minecraft 代码里剥离出来，
 * 既能单元测试，也方便以后加新枪。</p>
 */
public final class PerkEngine {

    /** 「亡命」叠加上限（最后的话语）。 */
    public static final int DESPERADO_MAX_STACKS = 5;
    /** 每层「亡命」的伤害加成。 */
    public static final float DESPERADO_PER_STACK = 0.06F;
    /** 雷神触发雷暴所需的连续命中数。 */
    public static final int THUNDER_HITS_REQUIRED = 3;
    /** 狼群弹数量。 */
    public static final int WOLFPACK_ROUNDS = 6;
    /** 旭日灼烧的持续伤害总段数。 */
    public static final int SUNBURN_TICKS = 5;
    /** 虚空奇点持续时间（tick）。 */
    public static final int SINGULARITY_TICKS = 40;

    private PerkEngine() {
    }

    /**
     * 特性带来的伤害倍率。
     *
     * @param perk 武器主特性
     * @param stacks 当前层数
     */
    public static float damageMultiplier(String perk, int stacks) {
        if ("desperado".equals(perk)) {
            int capped = Math.min(DESPERADO_MAX_STACKS, Math.max(0, stacks));
            return 1.0F + DESPERADO_PER_STACK * capped;
        }
        return 1.0F;
    }

    /** 命中后是否应该叠层。 */
    public static boolean stacksOnHit(String perk) {
        return "desperado".equals(perk);
    }

    /** 是否满足「连续命中 N 次」的爆发条件（雷神）。 */
    public static boolean shouldTriggerThunder(String perk, int hitStreak) {
        return "lightning_rounds".equals(perk) && hitStreak >= THUNDER_HITS_REQUIRED;
    }

    /** 击杀是否触发爆炸（命运终结者的萤火）。 */
    public static boolean triggersFirefly(String perk, boolean critical, boolean lethal) {
        return "firefly".equals(perk) && critical && lethal;
    }

    /** 击杀是否生成奇点（引力子长矛）。 */
    public static boolean triggersSingularity(String perk, boolean lethal) {
        return "black_hole".equals(perk) && lethal;
    }

    /** 是否每次命中都带小爆炸（旭日）。 */
    public static boolean hasImpactBlast(String perk) {
        return "sunblast".equals(perk);
    }

    /** 蓄力一击的最终伤害。 */
    public static float empoweredDamage(WeaponDef def, boolean empowered) {
        return empowered ? def.damage * def.empoweredMultiplier : def.damage;
    }
}
