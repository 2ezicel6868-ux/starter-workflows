package dev.destinyarsenal.combat;

import dev.destinyarsenal.core.Ballistics;
import dev.destinyarsenal.core.ElementKind;
import dev.destinyarsenal.core.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * 手写范围伤害。
 * <p>不用 {@code Level#explode}：一是原版爆炸会拆方块（枪械 mod 不希望玩家一炮拆家），
 * 二是自己算球体 + 距离衰减能精确控制伤害曲线。</p>
 */
public final class Explosions {

    private Explosions() {
    }

    /**
     * 对球形范围内的生物造成伤害并播放爆炸特效。
     *
     * @param source 伤害归属玩家
     * @param center 爆炸中心
     * @param radius 半径（格）
     * @param damage 中心处伤害
     */
    public static void damageArea(ServerLevel level, Player source, Vec3 center, double radius,
                                  float damage, ElementKind element) {
        AABB area = new AABB(
                center.x() - radius, center.y() - radius, center.z() - radius,
                center.x() + radius, center.y() + radius, center.z() + radius);

        List<Entity> entities = level.getEntities(source, area,
                entity -> entity instanceof LivingEntity && entity.isAlive() && !entity.isSpectator());

        net.minecraft.world.phys.Vec3 centerVec = McVec.toMc(center);
        for (Entity entity : entities) {
            double distance = entity.position().distanceTo(centerVec);
            if (distance > radius) {
                continue;
            }
            LivingEntity living = (LivingEntity) entity;
            float dealt = Ballistics.explosionDamage(damage, distance, radius);
            living.hurt(level.damageSources().playerAttack(source), dealt);

            // 轻微击退，让爆炸有「推」的感觉
            net.minecraft.world.phys.Vec3 away = entity.position().subtract(centerVec);
            if (away.lengthSqr() > 1.0E-4D) {
                net.minecraft.world.phys.Vec3 normalized = away.normalize();
                net.minecraft.world.phys.Vec3 velocity = entity.getDeltaMovement();
                entity.setDeltaMovement(
                        velocity.x + normalized.x * 0.35D,
                        Math.max(velocity.y, 0.22D),
                        velocity.z + normalized.z * 0.35D);
                entity.hasImpulse = true;
            }
        }

        Fx.explosion(level, center, element, radius);
    }
}
