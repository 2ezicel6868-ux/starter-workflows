package dev.destinyarsenal.combat;

import dev.destinyarsenal.core.Ballistics;
import dev.destinyarsenal.core.Box3;
import dev.destinyarsenal.core.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.List;

/**
 * 手写 hitscan：先打方块（决定最大距离），再对实体做「射线 vs 包围盒」求最近命中。
 * <p>不用 {@code ProjectileUtil}，因为它的签名在不同版本之间变过，
 * 自己算 slab 求交更稳，也方便实现穿透/精准判定。</p>
 */
public final class Hitscan {

    /**
     * @param target 命中的实体，{@code null} 表示只打到了方块或飞空
     * @param position 命中点（或射程终点）
     * @param critical 是否精准命中（爆头）
     * @param distance 命中距离
     * @param blocked 射线是否被方块挡住（决定要不要播放「打在墙上」的特效）
     */
    public record Hit(LivingEntity target, net.minecraft.world.phys.Vec3 position, boolean critical,
                      double distance, boolean blocked) {
        public boolean hitEntity() {
            return this.target != null;
        }
    }

    private Hitscan() {
    }

    public static Hit trace(ServerLevel level, Player shooter, Vec3 direction, double range) {
        net.minecraft.world.phys.Vec3 eye = shooter.getEyePosition();
        Vec3 origin = McVec.toCore(eye);
        Vec3 normalized = direction.normalize();
        net.minecraft.world.phys.Vec3 end = McVec.toMc(origin.add(normalized.scale(range)));

        BlockHitResult blockHit = level.clip(new ClipContext(
                eye, end,
                ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE,
                shooter));

        boolean blocked = blockHit.getType() != HitResult.Type.MISS;
        double limit = blocked ? eye.distanceTo(blockHit.getLocation()) : range;
        net.minecraft.world.phys.Vec3 fallback = blocked
                ? blockHit.getLocation()
                : McVec.toMc(origin.add(normalized.scale(range)));

        LivingEntity bestTarget = null;
        net.minecraft.world.phys.Vec3 bestPosition = null;
        boolean bestCritical = false;
        double bestDistance = limit;

        AABB search = new AABB(eye, end).inflate(2.0D);
        List<Entity> candidates = level.getEntities(shooter, search,
                entity -> entity instanceof LivingEntity && entity.isAlive()
                        && !entity.isSpectator() && !entity.isInvulnerable());

        for (Entity candidate : candidates) {
            AABB bounds = candidate.getBoundingBox();
            Box3 box = new Box3(
                    new Vec3(bounds.minX, bounds.minY, bounds.minZ),
                    new Vec3(bounds.maxX, bounds.maxY, bounds.maxZ));
            double distance = box.rayDistance(origin, normalized);
            if (distance == Double.MAX_VALUE || distance > bestDistance) {
                continue;
            }
            Vec3 point = origin.add(normalized.scale(distance));
            bestTarget = (LivingEntity) candidate;
            bestPosition = McVec.toMc(point);
            bestDistance = distance;
            bestCritical = Ballistics.isCriticalHit(point.y(), candidate.getY(), candidate.getBbHeight());
        }

        if (bestTarget != null) {
            return new Hit(bestTarget, bestPosition, bestCritical, bestDistance, false);
        }
        return new Hit(null, fallback, false, blocked ? limit : range, blocked);
    }
}
