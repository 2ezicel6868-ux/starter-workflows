package dev.destinyarsenal.combat;

import dev.destinyarsenal.core.ElementKind;
import dev.destinyarsenal.core.WeaponDef;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * 所有粒子 / 音效的出口。
 * <p>集中在一个类里，未来版本换了粒子或音效名字时只需要改这一个文件。</p>
 */
public final class Fx {

    private Fx() {
    }

    public static ParticleOptions elementParticle(ElementKind element) {
        return switch (element) {
            case SOLAR -> ParticleTypes.FLAME;
            case ARC -> ParticleTypes.ELECTRIC_SPARK;
            case VOID -> ParticleTypes.PORTAL;
            case STASIS -> ParticleTypes.SNOWFLAKE;
            default -> ParticleTypes.CRIT;
        };
    }

    /** 枪口焰。 */
    public static void muzzle(ServerLevel level, Player player, ElementKind element) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        double x = eye.x + look.x * 0.9D;
        double y = eye.y + look.y * 0.9D - 0.18D;
        double z = eye.z + look.z * 0.9D;
        level.sendParticles(ParticleTypes.SMOKE, x, y, z, 3, 0.02D, 0.02D, 0.02D, 0.01D);
        level.sendParticles(elementParticle(element), x, y, z, 5, 0.04D, 0.04D, 0.04D, 0.05D);
    }

    /** 开火音效：按枪种挑一个不一样的「响」。 */
    public static void shoot(ServerLevel level, Player player, WeaponDef def) {
        Vec3 eye = player.getEyePosition();
        switch (def.type) {
            case ROCKET_LAUNCHER, GRENADE_LAUNCHER -> level.playSound(null, eye.x, eye.y, eye.z,
                    SoundEvents.FIREWORK_ROCKET_LAUNCH, SoundSource.PLAYERS, 1.2F, 0.8F);
            case SNIPER_RIFLE -> level.playSound(null, eye.x, eye.y, eye.z,
                    SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, 1.0F, 0.7F);
            case HAND_CANNON -> level.playSound(null, eye.x, eye.y, eye.z,
                    SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 0.85F, 0.75F);
            default -> level.playSound(null, eye.x, eye.y, eye.z,
                    SoundEvents.CROSSBOW_SHOOT, SoundSource.PLAYERS, 0.55F, 1.5F);
        }
    }

    /** 命中实体。 */
    public static void hit(ServerLevel level, Vec3 position, ElementKind element, boolean critical) {
        level.sendParticles(critical ? ParticleTypes.CRIT : elementParticle(element),
                position.x(), position.y(), position.z(), critical ? 12 : 6,
                0.15D, 0.15D, 0.15D, 0.12D);
    }

    /** 命中方块/地面的碎屑。 */
    public static void impact(ServerLevel level, Vec3 position, ElementKind element) {
        level.sendParticles(elementParticle(element),
                position.x(), position.y(), position.z(), 8,
                0.12D, 0.12D, 0.12D, 0.08D);
        level.playSound(null, position.x(), position.y(), position.z(),
                SoundEvents.STONE_HIT, SoundSource.PLAYERS, 0.6F, 1.6F);
    }

    /** 爆炸。 */
    public static void explosion(ServerLevel level, Vec3 center, ElementKind element, double radius) {
        int count = (int) Math.min(28.0D, 6.0D + radius * 4.0D);
        level.sendParticles(ParticleTypes.EXPLOSION,
                center.x(), center.y(), center.z(), count,
                radius * 0.3D, radius * 0.3D, radius * 0.3D, 0.0D);
        level.sendParticles(elementParticle(element),
                center.x(), center.y(), center.z(), count * 2,
                radius * 0.35D, radius * 0.35D, radius * 0.35D, 0.12D);
        level.playSound(null, center.x(), center.y(), center.z(),
                SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.4F, 0.85F);
    }

    /** 蓄力一击的额外闪光。 */
    public static void empowered(ServerLevel level, Player player) {
        Vec3 eye = player.getEyePosition();
        level.sendParticles(ParticleTypes.END_ROD, eye.x, eye.y - 0.2D, eye.z, 24, 0.4D, 0.4D, 0.4D, 0.15D);
        level.playSound(null, eye.x, eye.y, eye.z,
                SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.2F, 0.6F);
    }

    public static void playAt(ServerLevel level, Vec3 position, SoundEvent sound, float volume, float pitch) {
        level.playSound(null, position.x(), position.y(), position.z(), sound, SoundSource.PLAYERS, volume, pitch);
    }
}
