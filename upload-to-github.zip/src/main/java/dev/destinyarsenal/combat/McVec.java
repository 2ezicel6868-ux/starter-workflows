package dev.destinyarsenal.combat;

import dev.destinyarsenal.core.Vec3;

/**
 * 纯 Java 向量与 Minecraft 向量之间的转换。
 * <p>两个类同名（{@code Vec3}），所以 Minecraft 那边一律写全限定名，避免 import 冲突。</p>
 */
public final class McVec {

    private McVec() {
    }

    public static net.minecraft.world.phys.Vec3 toMc(Vec3 v) {
        return new net.minecraft.world.phys.Vec3(v.x(), v.y(), v.z());
    }

    public static Vec3 toCore(net.minecraft.world.phys.Vec3 v) {
        return new Vec3(v.x, v.y, v.z);
    }

    public static Vec3 toCore(double x, double y, double z) {
        return new Vec3(x, y, z);
    }
}
