package dev.destinyarsenal.registry;

import dev.destinyarsenal.DestinyArsenal;
import dev.destinyarsenal.item.GunItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** 创造模式物品栏里的「命运 2 军械库」页签。 */
public final class ModItemGroup {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DestinyArsenal.MOD_ID);

    public static final RegistryObject<CreativeModeTab> ARSENAL = TABS.register("arsenal",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.destinyarsenal.arsenal"))
                    .icon(() -> new ItemStack(ModItems.GJALLARHORN.get()))
                    .displayItems((parameters, output) -> {
                        for (RegistryObject<GunItem> item : ModItems.ALL) {
                            output.accept(item.get());
                        }
                    })
                    .build());

    private ModItemGroup() {
    }

    public static void register(IEventBus modEventBus) {
        TABS.register(modEventBus);
    }
}
