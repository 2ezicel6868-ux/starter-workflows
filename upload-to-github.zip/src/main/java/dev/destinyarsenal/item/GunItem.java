package dev.destinyarsenal.item;

import dev.destinyarsenal.GunHandler;
import dev.destinyarsenal.core.WeaponDef;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Locale;

/**
 * 枪械物品。只负责「描述自己」并把操作转交给 {@link GunHandler}。
 * <p>注意 1.20.1 与 1.21.1 的两处签名差异：
 * {@code appendHoverText} 的第二个参数是 {@code Level}（不是 {@code Item.TooltipContext}），
 * {@code getUseDuration} 只有 {@code ItemStack} 一个参数。</p>
 */
public class GunItem extends Item {

    /** 蓄力武器的「使用时长」上限。 */
    public static final int MAX_USE_TICKS = 72000;

    private final WeaponDef def;

    public GunItem(WeaponDef def, Item.Properties properties) {
        super(properties);
        this.def = def;
    }

    public WeaponDef def() {
        return this.def;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return GunHandler.onUse(level, player, hand, this);
    }

    /** 蓄力武器需要「按住」状态，所以给一个极大值。 */
    @Override
    public int getUseDuration(ItemStack stack) {
        return this.def.chargeable ? MAX_USE_TICKS : 0;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return this.def.chargeable ? UseAnim.BOW : UseAnim.NONE;
    }

    @Override
    public boolean useOnRelease(ItemStack stack) {
        return this.def.chargeable;
    }

    @Override
    public boolean releaseUsing(ItemStack stack, Level level, LivingEntity entity, int timeLeft) {
        if (this.def.chargeable && entity instanceof Player player) {
            GunHandler.onChargeRelease(level, player, stack, this, timeLeft);
            return true;
        }
        return false;
    }

    /** 弹药条用元素色。 */
    @Override
    public int getBarColor(ItemStack stack) {
        return this.def.element.color();
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable(this.def.type.translationKey())
                .append(Component.literal(" · "))
                .append(Component.translatable(this.def.element.translationKey()))
                .withStyle(ChatFormatting.GRAY));

        tooltip.add(Component.translatable("tooltip.destinyarsenal.stats",
                String.format(Locale.ROOT, "%.1f", this.def.damage),
                this.def.magazine
        ).withStyle(ChatFormatting.DARK_GRAY));

        tooltip.add(Component.translatable("tooltip.destinyarsenal.perk",
                Component.translatable(this.def.perkNameKey())
        ).withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable(this.def.perkDescKey()).withStyle(ChatFormatting.DARK_GRAY));

        int rounds = this.def.roundsLeft(stack.getDamageValue());
        tooltip.add(Component.translatable("tooltip.destinyarsenal.ammo", rounds, this.def.magazine)
                .withStyle(rounds == 0 ? ChatFormatting.RED : ChatFormatting.AQUA));

        if (this.def.chargeable) {
            tooltip.add(Component.translatable("tooltip.destinyarsenal.charge",
                    String.format(Locale.ROOT, "%.1f", this.def.chargeTicks / 20.0D)
            ).withStyle(ChatFormatting.DARK_PURPLE));
        }
    }
}
