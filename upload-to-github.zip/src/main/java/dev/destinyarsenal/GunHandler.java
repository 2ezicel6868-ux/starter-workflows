package dev.destinyarsenal;

import dev.destinyarsenal.combat.Guns;
import dev.destinyarsenal.combat.Scheduler;
import dev.destinyarsenal.core.GunRuntime;
import dev.destinyarsenal.core.WeaponDef;
import dev.destinyarsenal.item.GunItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * 服务端枪械调度中心：开火、换弹、蓄力释放、每 tick 的换弹推进。
 * <ul>
 *     <li>右键：射击（按住连发）</li>
 *     <li>潜行 + 右键：主动换弹</li>
 *     <li>弹匣打空后再按右键：自动换弹</li>
 *     <li>蓄力武器（伊邪那岐的重担）：按住右键蓄力，松开发射</li>
 * </ul>
 */
public final class GunHandler {

    private static final Map<UUID, GunRuntime> STATE = new HashMap<>();

    private GunHandler() {
    }

    private static GunRuntime state(Player player) {
        return STATE.computeIfAbsent(player.getUUID(), uuid -> new GunRuntime());
    }

    // ---------------------------------------------------------------- 事件

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        long now = server.getTickCount();

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            GunRuntime runtime = STATE.get(player.getUUID());
            if (runtime == null) {
                continue;
            }
            ItemStack stack = player.getMainHandItem();
            if (!(stack.getItem() instanceof GunItem gun) || !gun.def().id.equals(runtime.weaponId())) {
                // 切枪 / 收枪：换弹与蓄力中断
                runtime.cancelReload();
                runtime.endCharge();
                continue;
            }
            if (runtime.isReloading() && runtime.finishReload(now)) {
                stack.setDamageValue(0);
                Level level = player.level();
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.CROSSBOW_LOADING_END, SoundSource.PLAYERS, 0.8F, 1.0F);
                player.displayClientMessage(Component.translatable("message.destinyarsenal.reloaded")
                        .withStyle(ChatFormatting.GREEN), true);
            }
        }

        Scheduler.tick(server);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        STATE.clear();
        Scheduler.clear();
    }

    // ---------------------------------------------------------------- 右键

    public static InteractionResultHolder<ItemStack> onUse(Level level, Player player, InteractionHand hand, GunItem gun) {
        ItemStack stack = player.getItemInHand(hand);
        WeaponDef def = gun.def();
        int rounds = def.roundsLeft(stack.getDamageValue());

        // 客户端只负责「表现」：决定要不要进入使用状态，真正的结算全在服务端
        if (level.isClientSide) {
            if (player.isShiftKeyDown() || rounds <= 0) {
                return InteractionResultHolder.fail(stack);
            }
            if (def.chargeable) {
                player.startUsingItem(hand);
                return InteractionResultHolder.consume(stack);
            }
            return InteractionResultHolder.success(stack);
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResultHolder.pass(stack);
        }

        GunRuntime runtime = state(player);
        runtime.select(def.id);
        long now = serverLevel.getServer().getTickCount();

        // 潜行 + 右键 = 主动换弹
        if (player.isShiftKeyDown()) {
            if (rounds >= def.magazine) {
                player.displayClientMessage(Component.translatable("message.destinyarsenal.reload_full")
                        .withStyle(ChatFormatting.GRAY), true);
                return InteractionResultHolder.fail(stack);
            }
            startReload(serverLevel, player, def, runtime, now);
            return InteractionResultHolder.success(stack);
        }

        if (def.chargeable) {
            if (rounds <= 0) {
                startReload(serverLevel, player, def, runtime, now);
                return InteractionResultHolder.fail(stack);
            }
            player.startUsingItem(hand);
            if (runtime.chargeStartTick() < 0) {
                runtime.beginCharge(now);
                serverLevel.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.CROSSBOW_LOADING_MIDDLE, SoundSource.PLAYERS, 0.45F, 1.7F);
            }
            return InteractionResultHolder.consume(stack);
        }

        if (rounds <= 0) {
            startReload(serverLevel, player, def, runtime, now);
            return InteractionResultHolder.fail(stack);
        }
        if (!runtime.canShoot(now, def.fireIntervalTicks)) {
            return InteractionResultHolder.fail(stack);
        }

        Guns.fire(serverLevel, player, stack, gun, runtime, false);
        return InteractionResultHolder.success(stack);
    }

    /** 蓄力武器松手时调用。 */
    public static void onChargeRelease(Level level, Player player, ItemStack stack, GunItem gun, int timeLeft) {
        if (level.isClientSide || !(level instanceof ServerLevel serverLevel)) {
            return;
        }
        WeaponDef def = gun.def();
        GunRuntime runtime = state(player);
        runtime.select(def.id);

        int usedTicks = Math.max(0, GunItem.MAX_USE_TICKS - timeLeft);
        runtime.endCharge();

        long now = serverLevel.getServer().getTickCount();
        if (!runtime.canShoot(now, def.fireIntervalTicks)) {
            return;
        }
        if (def.roundsLeft(stack.getDamageValue()) <= 0) {
            startReload(serverLevel, player, def, runtime, now);
            return;
        }
        boolean empowered = usedTicks >= def.chargeTicks;
        Guns.fire(serverLevel, player, stack, gun, runtime, empowered);
    }

    // ---------------------------------------------------------------- 换弹

    private static void startReload(ServerLevel level, Player player, WeaponDef def, GunRuntime runtime, long now) {
        if (!runtime.startReload(now, def.reloadTicks)) {
            return;
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.CROSSBOW_LOADING_START, SoundSource.PLAYERS, 0.8F, 1.0F);
        player.displayClientMessage(Component.translatable("message.destinyarsenal.reloading")
                .withStyle(ChatFormatting.GRAY), true);
    }
}
